import React, { useState, useEffect } from 'react';
import { X, Star, ShoppingCart, ExternalLink, Heart, Share2, BookOpen, Calendar, Award, Check, Minus, Plus } from 'lucide-react';
import { books } from '../data/booksData';
import { useCart } from '../contexts/CartContext';

interface BookDetailModalProps {
  bookId: number | null;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (bookId: number) => void;
}

const BookDetailModal: React.FC<BookDetailModalProps> = ({
  bookId,
  onClose,
  isWishlisted,
  onToggleWishlist,
}) => {
  const [activeTab, setActiveTab] = useState<'synopsis' | 'excerpt' | 'reviews'>('synopsis');
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);

  const { addToCart, isInCart } = useCart();
  const book = books.find((b) => b.id === bookId);
  const inCart = book ? isInCart(book.id) : false;

  useEffect(() => {
    if (bookId) {
      document.body.style.overflow = 'hidden';
      setQuantity(1);
      setAddedToCart(false);
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [bookId]);

  if (!book) return null;

  const handleAddToCart = () => {
    addToCart(book, quantity);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const handleShare = (platform: string) => {
    const url = window.location.href;
    const text = `Check out "${book.title}" by David Anane Nyarko (Papa David Snr.)!`;
    
    switch (platform) {
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`);
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`);
        break;
      case 'copy':
        navigator.clipboard.writeText(url);
        alert('Link copied to clipboard!');
        break;
    }
    setShowShareMenu(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-[#1a2332]/95 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-5xl max-h-[90vh] overflow-y-auto bg-[#1a2332] rounded-2xl border border-[#f5f1e8]/10 shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#f5f1e8]/20 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid md:grid-cols-2 gap-8 p-6 md:p-8">
          {/* Book Cover */}
          <div className="relative">
            <div className="sticky top-0">
              <img
                src={book.coverImage}
                alt={book.title}
                className="w-full max-w-sm mx-auto rounded-xl shadow-2xl"
              />
              
              {/* Actions below cover */}
              <div className="flex gap-3 mt-6 justify-center">
                <button
                  onClick={() => onToggleWishlist(book.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                    isWishlisted
                      ? 'bg-[#d4af37] text-[#1a2332]'
                      : 'bg-[#f5f1e8]/10 text-[#f5f1e8] hover:bg-[#f5f1e8]/20'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                  {isWishlisted ? 'Saved' : 'Save'}
                </button>
                <div className="relative">
                  <button
                    onClick={() => setShowShareMenu(!showShareMenu)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#f5f1e8]/10 text-[#f5f1e8] rounded-lg hover:bg-[#f5f1e8]/20 transition-colors"
                  >
                    <Share2 className="w-4 h-4" />
                    Share
                  </button>
                  {showShareMenu && (
                    <div className="absolute top-full mt-2 right-0 bg-[#1a2332] border border-[#f5f1e8]/10 rounded-lg shadow-xl overflow-hidden z-10">
                      <button
                        onClick={() => handleShare('twitter')}
                        className="block w-full px-4 py-2 text-left text-[#f5f1e8] hover:bg-[#f5f1e8]/10"
                      >
                        Twitter
                      </button>
                      <button
                        onClick={() => handleShare('facebook')}
                        className="block w-full px-4 py-2 text-left text-[#f5f1e8] hover:bg-[#f5f1e8]/10"
                      >
                        Facebook
                      </button>
                      <button
                        onClick={() => handleShare('copy')}
                        className="block w-full px-4 py-2 text-left text-[#f5f1e8] hover:bg-[#f5f1e8]/10"
                      >
                        Copy Link
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Book Details */}
          <div className="space-y-6">
            {/* Header */}
            <div>
              {book.series && (
                <p className="text-[#d4af37] text-sm font-medium mb-2">
                  {book.series} {book.seriesNumber && `#${book.seriesNumber}`}
                </p>
              )}
              <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-[#f5f1e8] mb-2">
                {book.title}
              </h2>
              {book.subtitle && (
                <p className="text-[#f5f1e8]/60 text-lg">{book.subtitle}</p>
              )}
              <p className="text-[#d4af37] mt-2">
                by David Anane Nyarko (Papa David Snr.)
              </p>
            </div>

            {/* Rating & Meta */}
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(book.rating)
                          ? 'text-[#d4af37] fill-[#d4af37]'
                          : 'text-[#f5f1e8]/20'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-[#f5f1e8]">{book.rating}</span>
                <span className="text-[#f5f1e8]/50">
                  ({book.reviewCount} reviews)
                </span>
              </div>
            </div>

            {/* Meta Info */}
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2 text-[#f5f1e8]/60">
                <BookOpen className="w-4 h-4" />
                {book.genre}
              </div>
              <div className="flex items-center gap-2 text-[#f5f1e8]/60">
                <Calendar className="w-4 h-4" />
                {new Date(book.publishDate).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </div>
            </div>

            {/* Awards */}
            {book.awards && book.awards.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {book.awards.map((award, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-[#d4af37]/20 text-[#d4af37] text-sm rounded-full"
                  >
                    <Award className="w-3 h-3" />
                    {award}
                  </span>
                ))}
              </div>
            )}

            {/* Price & Add to Cart */}
            <div className="py-4 border-y border-[#f5f1e8]/10 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-bold text-[#f5f1e8]">
                  ${book.price.toFixed(2)}
                </span>
                {inCart && !addedToCart && (
                  <span className="text-green-400 text-sm flex items-center gap-1">
                    <Check className="w-4 h-4" />
                    In your cart
                  </span>
                )}
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center gap-4">
                <span className="text-[#f5f1e8]/60 text-sm">Quantity:</span>
                <div className="flex items-center bg-[#f5f1e8]/5 rounded-lg border border-[#f5f1e8]/10">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 text-[#f5f1e8]/60 hover:text-[#f5f1e8] transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 text-[#f5f1e8] font-medium min-w-[40px] text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2 text-[#f5f1e8]/60 hover:text-[#f5f1e8] transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <span className="text-[#f5f1e8]/50 text-sm">
                  Total: ${(book.price * quantity).toFixed(2)}
                </span>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={handleAddToCart}
                className={`w-full flex items-center justify-center gap-2 py-3 font-semibold rounded-lg transition-all ${
                  addedToCart
                    ? 'bg-green-500 text-white'
                    : 'bg-[#d4af37] text-[#1a2332] hover:bg-[#e5c04a]'
                }`}
              >
                {addedToCart ? (
                  <>
                    <Check className="w-5 h-5" />
                    Added to Cart!
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-5 h-5" />
                    Add to Cart
                  </>
                )}
              </button>
            </div>

            {/* Purchase Links */}
            <div className="space-y-3">
              <p className="text-[#f5f1e8]/60 text-sm">Available on Amazon KDP:</p>
              <div className="flex flex-wrap gap-3">
                <a
                  href={book.amazonLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-lg hover:bg-[#e5c04a] transition-colors"
                >
                  Buy on Amazon
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Tabs */}
            <div className="border-b border-[#f5f1e8]/10">
              <div className="flex gap-6">
                {(['synopsis', 'excerpt', 'reviews'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`pb-3 text-sm font-medium capitalize transition-colors ${
                      activeTab === tab
                        ? 'text-[#d4af37] border-b-2 border-[#d4af37]'
                        : 'text-[#f5f1e8]/60 hover:text-[#f5f1e8]'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* Tab Content */}
            <div className="min-h-[150px]">
              {activeTab === 'synopsis' && (
                <p className="text-[#f5f1e8]/80 leading-relaxed">
                  {book.synopsis}
                </p>
              )}
              {activeTab === 'excerpt' && (
                <blockquote className="text-[#f5f1e8]/80 italic leading-relaxed border-l-4 border-[#d4af37] pl-4">
                  "{book.excerpt}"
                </blockquote>
              )}
              {activeTab === 'reviews' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="text-4xl font-bold text-[#d4af37]">{book.rating}</div>
                    <div>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-5 h-5 ${
                              i < Math.floor(book.rating)
                                ? 'text-[#d4af37] fill-[#d4af37]'
                                : 'text-[#f5f1e8]/20'
                            }`}
                          />
                        ))}
                      </div>
                      <p className="text-[#f5f1e8]/60 text-sm">
                        Based on {book.reviewCount} reviews
                      </p>
                    </div>
                  </div>
                  <p className="text-[#f5f1e8]/60 text-sm">
                    Read more reviews on Amazon
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookDetailModal;
