import React, { useState, useEffect, useRef } from 'react';
import Header from './Header';
import Hero from './Hero';
import BookGrid from './BookGrid';
import BookDetailModal from './BookDetailModal';
import AuthorBio from './AuthorBio';
import Testimonials from './Testimonials';
import BlogSection from './BlogSection';
import EventsSection from './EventsSection';
import Newsletter from './Newsletter';
import ContactSection from './ContactSection';
import SeriesShowcase from './SeriesShowcase';
import Footer from './Footer';
import CartDrawer from './CartDrawer';
import { CartProvider } from '../contexts/CartContext';

const AppLayoutContent: React.FC = () => {
  const [currentSection, setCurrentSection] = useState('home');
  const [selectedBookId, setSelectedBookId] = useState<number | null>(null);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Refs for scroll navigation
  const homeRef = useRef<HTMLDivElement>(null);
  const booksRef = useRef<HTMLDivElement>(null);
  const aboutRef = useRef<HTMLDivElement>(null);
  const blogRef = useRef<HTMLDivElement>(null);
  const eventsRef = useRef<HTMLDivElement>(null);
  const contactRef = useRef<HTMLDivElement>(null);

  const handleNavigate = (section: string) => {
    setCurrentSection(section);
    
    const refs: Record<string, React.RefObject<HTMLDivElement>> = {
      home: homeRef,
      books: booksRef,
      about: aboutRef,
      blog: blogRef,
      events: eventsRef,
      contact: contactRef,
    };

    const targetRef = refs[section];
    if (targetRef?.current) {
      targetRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectBook = (bookId: number) => {
    setSelectedBookId(bookId);
  };

  const handleCloseModal = () => {
    setSelectedBookId(null);
  };

  const handleToggleWishlist = (bookId: number) => {
    setWishlist((prev) =>
      prev.includes(bookId)
        ? prev.filter((id) => id !== bookId)
        : [...prev, bookId]
    );
  };

  const handleOpenCart = () => {
    setIsCartOpen(true);
  };

  const handleCloseCart = () => {
    setIsCartOpen(false);
  };

  // Update current section based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      const sections = [
        { id: 'home', ref: homeRef },
        { id: 'books', ref: booksRef },
        { id: 'about', ref: aboutRef },
        { id: 'blog', ref: blogRef },
        { id: 'events', ref: eventsRef },
        { id: 'contact', ref: contactRef },
      ];

      const scrollPosition = window.scrollY + 200;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section.ref.current) {
          const offsetTop = section.ref.current.offsetTop;
          if (scrollPosition >= offsetTop) {
            setCurrentSection(section.id);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#1a2332]">
      {/* Custom Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
          font-family: 'Inter', sans-serif;
        }
        
        .font-playfair {
          font-family: 'Playfair Display', serif;
        }
      `}</style>

      {/* Header */}
      <Header 
        onNavigate={handleNavigate} 
        currentSection={currentSection} 
        onOpenCart={handleOpenCart}
      />

      {/* Main Content */}
      <main>
        {/* Hero Section */}
        <div ref={homeRef}>
          <Hero onNavigate={handleNavigate} onSelectBook={handleSelectBook} />
        </div>

        {/* Series Showcase */}
        <SeriesShowcase onSelectBook={handleSelectBook} />

        {/* Books Grid */}
        <div ref={booksRef}>
          <BookGrid
            onSelectBook={handleSelectBook}
            wishlist={wishlist}
            onToggleWishlist={handleToggleWishlist}
          />
        </div>

        {/* Author Bio */}
        <div ref={aboutRef}>
          <AuthorBio onNavigate={handleNavigate} />
        </div>

        {/* Testimonials */}
        <Testimonials />

        {/* Newsletter */}
        <Newsletter />

        {/* Blog Section */}
        <div ref={blogRef}>
          <BlogSection onNavigate={handleNavigate} />
        </div>

        {/* Events Section */}
        <div ref={eventsRef}>
          <EventsSection />
        </div>

        {/* Contact Section */}
        <div ref={contactRef}>
          <ContactSection />
        </div>
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} onSelectBook={handleSelectBook} />

      {/* Book Detail Modal */}
      {selectedBookId && (
        <BookDetailModal
          bookId={selectedBookId}
          onClose={handleCloseModal}
          isWishlisted={wishlist.includes(selectedBookId)}
          onToggleWishlist={handleToggleWishlist}
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer isOpen={isCartOpen} onClose={handleCloseCart} />
    </div>
  );
};

// Wrap with CartProvider
const AppLayout: React.FC = () => {
  return (
    <CartProvider>
      <AppLayoutContent />
    </CartProvider>
  );
};

export default AppLayout;
