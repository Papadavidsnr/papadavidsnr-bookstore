import React, { useState } from 'react';
import { Calendar, Clock, ArrowRight, BookOpen } from 'lucide-react';
import { blogPosts } from '../data/booksData';

interface BlogSectionProps {
  onNavigate: (section: string) => void;
}

const BlogSection: React.FC<BlogSectionProps> = ({ onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [expandedPost, setExpandedPost] = useState<number | null>(null);

  const categories = ['All', ...new Set(blogPosts.map((post) => post.category))];

  const filteredPosts =
    selectedCategory === 'All'
      ? blogPosts
      : blogPosts.filter((post) => post.category === selectedCategory);

  const featuredPost = blogPosts[0];
  const regularPosts = filteredPosts.slice(1, 7);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <section id="blog" className="py-20 bg-[#1a2332]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <p className="text-[#d4af37] text-sm font-medium uppercase tracking-wider mb-2">
            Inspiration & Insights
          </p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#f5f1e8] mb-4">
            Latest <span className="text-[#d4af37]">Blog Posts</span>
          </h2>
          <p className="text-[#f5f1e8]/60 max-w-2xl mx-auto">
            Encouraging words on faith, marriage, and relationships to help you 
            grow spiritually and build stronger connections.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCategory === category
                  ? 'bg-[#d4af37] text-[#1a2332]'
                  : 'bg-[#f5f1e8]/10 text-[#f5f1e8]/70 hover:bg-[#f5f1e8]/20'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Featured Post */}
        <div className="mb-12">
          <div
            className="group relative bg-gradient-to-r from-[#d4af37]/20 to-transparent rounded-2xl overflow-hidden cursor-pointer"
            onClick={() => setExpandedPost(expandedPost === featuredPost.id ? null : featuredPost.id)}
          >
            <div className="grid md:grid-cols-2 gap-8 p-8">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-[#d4af37] text-[#1a2332] text-xs font-bold rounded-full">
                    FEATURED
                  </span>
                  <span className="px-3 py-1 bg-[#f5f1e8]/10 text-[#f5f1e8]/70 text-xs rounded-full">
                    {featuredPost.category}
                  </span>
                </div>
                <h3 className="font-['Playfair_Display'] text-2xl md:text-3xl font-bold text-[#f5f1e8] group-hover:text-[#d4af37] transition-colors">
                  {featuredPost.title}
                </h3>
                <p className="text-[#f5f1e8]/70 leading-relaxed">
                  {featuredPost.excerpt}
                </p>
                <div className="flex items-center gap-4 text-sm text-[#f5f1e8]/50">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {formatDate(featuredPost.date)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {featuredPost.readTime} min read
                  </span>
                </div>
                <button className="inline-flex items-center gap-2 text-[#d4af37] font-medium group-hover:gap-3 transition-all">
                  Read More
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
              <div className="hidden md:flex items-center justify-center">
                <div className="w-48 h-48 bg-[#d4af37]/20 rounded-full flex items-center justify-center">
                  <BookOpen className="w-24 h-24 text-[#d4af37]/40" />
                </div>
              </div>
            </div>
            
            {/* Expanded Content */}
            {expandedPost === featuredPost.id && (
              <div className="px-8 pb-8 border-t border-[#f5f1e8]/10 pt-6">
                <p className="text-[#f5f1e8]/80 leading-relaxed">
                  {featuredPost.content}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Blog Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regularPosts.map((post) => (
            <article
              key={post.id}
              className="group bg-[#f5f1e8]/5 rounded-xl overflow-hidden border border-[#f5f1e8]/10 hover:border-[#d4af37]/30 transition-all cursor-pointer"
              onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
            >
              <div className="p-6 space-y-4">
                {/* Category & Date */}
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 bg-[#d4af37]/20 text-[#d4af37] text-xs rounded-full">
                    {post.category}
                  </span>
                  <span className="text-[#f5f1e8]/40 text-xs">
                    {formatDate(post.date)}
                  </span>
                </div>

                {/* Title */}
                <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#f5f1e8] group-hover:text-[#d4af37] transition-colors line-clamp-2">
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-[#f5f1e8]/60 text-sm line-clamp-2">
                  {post.excerpt}
                </p>

                {/* Meta */}
                <div className="flex items-center justify-between pt-4 border-t border-[#f5f1e8]/10">
                  <span className="flex items-center gap-1 text-[#f5f1e8]/40 text-sm">
                    <Clock className="w-4 h-4" />
                    {post.readTime} min read
                  </span>
                  <span className="text-[#d4af37] text-sm font-medium group-hover:underline">
                    Read More
                  </span>
                </div>
              </div>

              {/* Expanded Content */}
              {expandedPost === post.id && (
                <div className="px-6 pb-6 border-t border-[#f5f1e8]/10 pt-4">
                  <p className="text-[#f5f1e8]/80 text-sm leading-relaxed">
                    {post.content}
                  </p>
                </div>
              )}
            </article>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <button
            onClick={() => onNavigate('blog')}
            className="inline-flex items-center gap-2 px-8 py-3 border-2 border-[#d4af37] text-[#d4af37] font-semibold rounded-full hover:bg-[#d4af37] hover:text-[#1a2332] transition-all"
          >
            View All Posts
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default BlogSection;
