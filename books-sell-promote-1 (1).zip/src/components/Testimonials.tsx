import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { reviews } from '../data/booksData';

const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const reviewsPerPage = 3;
  const totalPages = Math.ceil(reviews.length / reviewsPerPage);

  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % totalPages);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, totalPages]);

  const goToPage = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
  };

  const goToPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + totalPages) % totalPages);
    setIsAutoPlaying(false);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % totalPages);
    setIsAutoPlaying(false);
  };

  const currentReviews = reviews.slice(
    currentIndex * reviewsPerPage,
    (currentIndex + 1) * reviewsPerPage
  );

  return (
    <section className="py-20 bg-[#f5f1e8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <p className="text-[#d4af37] text-sm font-medium uppercase tracking-wider mb-2">
            Reader Reviews
          </p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#1a2332] mb-4">
            What Readers Are <span className="text-[#d4af37]">Saying</span>
          </h2>
          <p className="text-[#1a2332]/60 max-w-2xl mx-auto">
            Discover how these books have touched lives and strengthened faith around the world.
          </p>
        </div>

        {/* Reviews Carousel */}
        <div className="relative">
          {/* Navigation Buttons */}
          <button
            onClick={goToPrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 p-3 bg-white rounded-full shadow-lg text-[#1a2332] hover:bg-[#d4af37] hover:text-white transition-colors hidden md:block"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 p-3 bg-white rounded-full shadow-lg text-[#1a2332] hover:bg-[#d4af37] hover:text-white transition-colors hidden md:block"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Reviews Grid */}
          <div className="grid md:grid-cols-3 gap-6">
            {currentReviews.map((review, index) => (
              <div
                key={review.id}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow relative"
                style={{
                  animation: `fadeIn 0.5s ease-out ${index * 0.1}s both`,
                }}
              >
                {/* Quote Icon */}
                <Quote className="absolute top-4 right-4 w-8 h-8 text-[#d4af37]/20" />

                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < review.rating
                          ? 'text-[#d4af37] fill-[#d4af37]'
                          : 'text-gray-200'
                      }`}
                    />
                  ))}
                </div>

                {/* Review Text */}
                <p className="text-[#1a2332]/80 leading-relaxed mb-6 italic">
                  "{review.text}"
                </p>

                {/* Reviewer Info */}
                <div className="border-t border-gray-100 pt-4">
                  <p className="font-semibold text-[#1a2332]">{review.reviewer}</p>
                  {review.source && (
                    <p className="text-[#d4af37] text-sm">{review.source}</p>
                  )}
                  <p className="text-[#1a2332]/50 text-sm mt-1">
                    on "{review.bookTitle}"
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pagination Dots */}
        <div className="flex justify-center gap-2 mt-8">
          {[...Array(totalPages)].map((_, index) => (
            <button
              key={index}
              onClick={() => goToPage(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentIndex
                  ? 'bg-[#d4af37] w-8'
                  : 'bg-[#1a2332]/20 hover:bg-[#1a2332]/40'
              }`}
            />
          ))}
        </div>

        {/* Featured Quote */}
        <div className="mt-16 text-center">
          <div className="inline-block bg-[#1a2332] rounded-2xl p-8 md:p-12 max-w-3xl">
            <Quote className="w-12 h-12 text-[#d4af37] mx-auto mb-6" />
            <blockquote className="font-['Playfair_Display'] text-2xl md:text-3xl text-[#f5f1e8] italic leading-relaxed mb-6">
              "Papa David Snr.'s books have been a tremendous blessing to my spiritual journey. 
              His wisdom on faith and relationships is both practical and deeply rooted in Scripture."
            </blockquote>
            <cite className="text-[#d4af37] font-medium not-italic">
              — A Grateful Reader
            </cite>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  );
};

export default Testimonials;
