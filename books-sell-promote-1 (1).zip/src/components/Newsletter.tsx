import React, { useState } from 'react';
import { Mail, Gift, Check, Loader2, BookOpen, Star, Heart } from 'lucide-react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email) {
      setError('Please enter your email address');
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please enter a valid email address');
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSubscribed(true);
  };

  const benefits = [
    'New book release announcements',
    'Exclusive devotional content',
    'Marriage & relationship tips',
    'Special discounts on books',
    'Inspiring faith messages',
  ];

  return (
    <section className="py-20 bg-[#f5f1e8] relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-[#d4af37]/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#1a2332]/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content Side */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#d4af37]/20 rounded-full">
              <Heart className="w-4 h-4 text-[#d4af37]" />
              <span className="text-[#1a2332] text-sm font-medium">
                Join Our Community
              </span>
            </div>

            <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#1a2332]">
              Stay Connected
              <span className="block text-[#d4af37]">& Inspired</span>
            </h2>

            <p className="text-[#1a2332]/70 text-lg leading-relaxed">
              Subscribe to receive encouraging messages, new book announcements, 
              and exclusive content from Papa David Snr. to help strengthen your 
              faith and relationships.
            </p>

            {/* Benefits List */}
            <ul className="space-y-3">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#d4af37]/20 flex items-center justify-center flex-shrink-0">
                    <Check className="w-4 h-4 text-[#d4af37]" />
                  </div>
                  <span className="text-[#1a2332]/70">{benefit}</span>
                </li>
              ))}
            </ul>

            {/* Lead Magnet Preview */}
            <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-lg">
              <div className="w-16 h-20 bg-[#1a2332] rounded-lg flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-8 h-8 text-[#d4af37]" />
              </div>
              <div>
                <p className="text-[#1a2332] font-semibold">Free Devotional Guide</p>
                <p className="text-[#1a2332]/60 text-sm">
                  "7 Days of Strengthening Your Faith"
                </p>
                <div className="flex items-center gap-1 mt-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 text-[#d4af37] fill-[#d4af37]" />
                  ))}
                  <span className="text-xs text-[#1a2332]/50 ml-1">
                    Exclusive for subscribers
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-[#1a2332] rounded-2xl p-8 md:p-10 shadow-2xl">
            {!isSubscribed ? (
              <>
                <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8] mb-2">
                  Get Your Free Devotional
                </h3>
                <p className="text-[#f5f1e8]/60 mb-6">
                  Enter your email below to receive your free 7-day devotional guide instantly.
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="email" className="sr-only">
                      Email address
                    </label>
                    <div className="relative">
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email address"
                        className="w-full px-5 py-4 pl-12 bg-[#f5f1e8]/10 border border-[#f5f1e8]/20 rounded-xl text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none focus:border-[#d4af37] transition-colors"
                      />
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#f5f1e8]/40" />
                    </div>
                    {error && (
                      <p className="mt-2 text-red-400 text-sm">{error}</p>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-[#d4af37] text-[#1a2332] font-semibold rounded-xl hover:bg-[#e5c04a] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Subscribing...
                      </>
                    ) : (
                      <>
                        <Gift className="w-5 h-5" />
                        Get My Free Devotional
                      </>
                    )}
                  </button>
                </form>

                <p className="mt-4 text-[#f5f1e8]/40 text-xs text-center">
                  By subscribing, you agree to receive email updates. You can unsubscribe at any time.
                  Your privacy is respected and your information will never be shared.
                </p>

                {/* Social Proof */}
                <div className="mt-8 pt-6 border-t border-[#f5f1e8]/10">
                  <p className="text-[#f5f1e8]/60 text-sm text-center">
                    Join <span className="text-[#d4af37] font-semibold">hundreds</span> of readers 
                    who receive encouraging content
                  </p>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <div className="w-20 h-20 mx-auto mb-6 bg-[#d4af37]/20 rounded-full flex items-center justify-center">
                  <Check className="w-10 h-10 text-[#d4af37]" />
                </div>
                <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8] mb-2">
                  Welcome to the Family!
                </h3>
                <p className="text-[#f5f1e8]/60 mb-6">
                  Check your inbox for your free devotional guide. God bless you!
                </p>
                <div className="p-4 bg-[#f5f1e8]/5 rounded-xl">
                  <p className="text-[#f5f1e8]/80 text-sm">
                    Don't see it? Check your spam folder and add{' '}
                    <span className="text-[#d4af37]">papadavidsnr@gmail.com</span> to your contacts.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
