import React from 'react';
import { Award, BookOpen, Users, Feather, Instagram, Twitter, Facebook, Mail, Heart, Linkedin } from 'lucide-react';
import { authorImages, socialLinks } from '../data/booksData';

// TikTok icon component
const TikTokIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
  </svg>
);

interface AuthorBioProps {
  onNavigate: (section: string) => void;
}

const AuthorBio: React.FC<AuthorBioProps> = ({ onNavigate }) => {
  const achievements = [
    { icon: BookOpen, label: 'Published Books', value: '4' },
    { icon: Heart, label: 'Lives Touched', value: '350+' },
    { icon: Users, label: 'Readers Worldwide', value: 'Growing' },
    { icon: Feather, label: 'Years Writing', value: '5+' },
  ];

  const bookTopics = [
    { title: "Faith & Spiritual Growth", description: "Exploring God's persistence and silence in our lives" },
    { title: "Marriage & Family", description: "Strengthening bonds through biblical principles" },
    { title: "Relationships", description: "Building meaningful connections without stress" },
    { title: "Christian Living", description: "Practical wisdom for everyday faith" },
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-[#1a2332] to-[#0f1520]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="relative">
              {/* Decorative Elements */}
              <div className="absolute -top-4 -left-4 w-72 h-72 bg-[#d4af37]/10 rounded-full blur-3xl" />
              <div className="absolute -bottom-4 -right-4 w-48 h-48 bg-[#d4af37]/20 rounded-full blur-2xl" />
              
              {/* Main Image */}
              <div className="relative">
                <div className="w-full max-w-md mx-auto overflow-hidden rounded-2xl shadow-2xl">
                  <img 
                    src={authorImages.primary} 
                    alt="David Anane Nyarko - Papa David Snr."
                    className="w-full h-auto object-cover"
                  />
                </div>
                
                {/* Floating Card */}
                <div className="absolute -bottom-6 -right-6 bg-[#1a2332] p-4 rounded-xl border border-[#d4af37]/30 shadow-xl">
                  <p className="text-[#d4af37] text-sm font-medium">Amazon KDP</p>
                  <p className="text-[#f5f1e8] font-['Playfair_Display'] text-lg font-bold">
                    Published Author
                  </p>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4 mt-12">
              {achievements.map((item, index) => (
                <div
                  key={index}
                  className="bg-[#f5f1e8]/5 rounded-xl p-4 border border-[#f5f1e8]/10 hover:border-[#d4af37]/30 transition-colors"
                >
                  <item.icon className="w-6 h-6 text-[#d4af37] mb-2" />
                  <div className="text-2xl font-bold text-[#f5f1e8]">{item.value}</div>
                  <div className="text-[#f5f1e8]/50 text-sm">{item.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Content Side */}
          <div className="space-y-8">
            <div>
              <p className="text-[#d4af37] text-sm font-medium uppercase tracking-wider mb-2">
                About the Author
              </p>
              <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#f5f1e8] mb-6">
                David Anane Nyarko
                <span className="block text-[#d4af37] text-2xl md:text-3xl mt-2">(Papa David Snr.)</span>
              </h2>
            </div>

            <div className="space-y-4 text-[#f5f1e8]/70 leading-relaxed">
              <p>
                David Anane Nyarko, affectionately known as Papa David Snr., is a passionate 
                author dedicated to helping people strengthen their faith, improve their 
                relationships, and navigate life's challenges with biblical wisdom.
              </p>
              <p>
                With a heart for ministry and a gift for making spiritual truths practical 
                and accessible, Papa David Snr. writes books that speak directly to the 
                struggles and questions many believers face. His work addresses topics 
                ranging from understanding God's silence to building stronger marriages 
                and valuing the relationships in our lives.
              </p>
              <p>
                Through his books published on Amazon KDP, Papa David Snr. reaches readers 
                around the world, offering hope, encouragement, and practical guidance 
                rooted in Scripture. His writing style combines personal testimony, 
                biblical insight, and actionable wisdom that readers can apply immediately.
              </p>
            </div>

            {/* Book Topics Section */}
            <div className="bg-[#f5f1e8]/5 rounded-xl p-6 border border-[#f5f1e8]/10">
              <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#f5f1e8] mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#d4af37]" />
                Topics I Write About
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {bookTopics.map((topic, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-2 h-2 mt-2 bg-[#d4af37] rounded-full flex-shrink-0" />
                    <div>
                      <p className="text-[#f5f1e8] font-medium">{topic.title}</p>
                      <p className="text-[#f5f1e8]/50 text-sm">{topic.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Mission Statement */}
            <div className="bg-gradient-to-r from-[#d4af37]/10 to-transparent rounded-xl p-6 border-l-4 border-[#d4af37]">
              <p className="text-[#f5f1e8] italic text-lg">
                "My mission is to help people discover God's unfailing love, build stronger 
                relationships, and live lives of purpose and meaning through faith-based wisdom."
              </p>
              <p className="text-[#d4af37] font-medium mt-2">— Papa David Snr.</p>
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              <span className="text-[#f5f1e8]/50 text-sm">Connect with me:</span>
              <div className="flex gap-3">
                <a
                  href={socialLinks.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                  title="Instagram"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href={socialLinks.twitter}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                  title="X (Twitter)"
                >
                  <Twitter className="w-5 h-5" />
                </a>
                <a
                  href={socialLinks.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                  title="Facebook"
                >
                  <Facebook className="w-5 h-5" />
                </a>
                <a
                  href={socialLinks.tiktok}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                  title="TikTok"
                >
                  <TikTokIcon className="w-5 h-5" />
                </a>
                <a
                  href={socialLinks.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                  title="LinkedIn"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
                <a
                  href={`mailto:${socialLinks.email}`}
                  className="p-2 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                  title="Email"
                >
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* CTA */}
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => onNavigate('books')}
                className="px-8 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-full hover:bg-[#e5c04a] transition-all hover:shadow-lg hover:shadow-[#d4af37]/20"
              >
                View My Books
              </button>
              <button
                onClick={() => onNavigate('contact')}
                className="px-8 py-3 border-2 border-[#f5f1e8]/30 text-[#f5f1e8] font-semibold rounded-full hover:border-[#d4af37] hover:text-[#d4af37] transition-all"
              >
                Get in Touch
              </button>
            </div>
          </div>
        </div>

        {/* Second Photo Section */}
        <div className="mt-20 grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1 space-y-6">
            <h3 className="font-['Playfair_Display'] text-3xl font-bold text-[#f5f1e8]">
              A Heart for Ministry
            </h3>
            <p className="text-[#f5f1e8]/70 leading-relaxed">
              Beyond writing, Papa David Snr. is actively involved in ministry, speaking at 
              churches, conferences, and workshops. His passion is to see lives transformed 
              through the power of God's Word and practical wisdom.
            </p>
            <p className="text-[#f5f1e8]/70 leading-relaxed">
              Whether through his books, speaking engagements, or one-on-one mentoring, 
              David is committed to helping individuals and couples build stronger foundations 
              for their faith and relationships.
            </p>
            <div className="flex gap-4">
              <a
                href={socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-[#d4af37] hover:underline"
              >
                <Linkedin className="w-5 h-5" />
                Connect on LinkedIn
              </a>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="absolute -top-4 -right-4 w-48 h-48 bg-[#d4af37]/10 rounded-full blur-3xl" />
              <div className="w-full max-w-md mx-auto overflow-hidden rounded-2xl shadow-2xl">
                <img 
                  src={authorImages.secondary} 
                  alt="David Anane Nyarko - Speaking and Ministry"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AuthorBio;
