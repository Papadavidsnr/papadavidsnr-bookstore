import React, { useState } from 'react';
import { ChevronRight, Star, ShoppingCart, Check, BookOpen, Heart } from 'lucide-react';
import { books, Book } from '../data/booksData';
import { useCart } from '../contexts/CartContext';

interface SeriesShowcaseProps {
  onSelectBook: (bookId: number) => void;
}

const SeriesShowcase: React.FC<SeriesShowcaseProps> = ({ onSelectBook }) => {
  const { addToCart, isInCart } = useCart();
  const [addedBookId, setAddedBookId] = useState<number | null>(null);

  // Group books by series
  const faithJourneySeries = books.filter((book) => book.series === 'Faith Journey');
  const relationshipWisdomSeries = books.filter((book) => book.series === 'Relationship Wisdom');

  const handleAddToCart = (e: React.MouseEvent, book: Book) => {
    e.stopPropagation();
    addToCart(book);
    setAddedBookId(book.id);
    setTimeout(() => setAddedBookId(null), 1500);
  };

  const SeriesRow = ({
    title,
    description,
    seriesBooks,
    icon: Icon,
  }: {
    title: string;
    description: string;
    seriesBooks: typeof books;
    icon: React.ComponentType<{ className?: string }>;
  }) => (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div className="flex items-start gap-3">
          <div className="p-3 bg-[#d4af37]/20 rounded-lg">
            <Icon className="w-6 h-6 text-[#d4af37]" />
          </div>
          <div>
            <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8]">
              {title}
            </h3>
            <p className="text-[#f5f1e8]/60 mt-1">{description}</p>
          </div>
        </div>
      </div>

      <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-hide">
        {seriesBooks
          .sort((a, b) => (a.seriesNumber || 0) - (b.seriesNumber || 0))
          .map((book) => {
            const inCart = isInCart(book.id);
            const justAdded = addedBookId === book.id;
            
            return (
              <div
                key={book.id}
                onClick={() => onSelectBook(book.id)}
                className="flex-shrink-0 w-48 group cursor-pointer"
              >
                <div className="relative mb-3">
                  <img
                    src={book.coverImage}
                    alt={book.title}
                    className="w-full aspect-[3/4] object-cover rounded-lg shadow-lg group-hover:shadow-xl group-hover:scale-105 transition-all duration-300"
                  />
                  {book.seriesNumber && (
                    <div className="absolute top-2 left-2 w-8 h-8 bg-[#d4af37] rounded-full flex items-center justify-center text-[#1a2332] font-bold text-sm">
                      {book.seriesNumber}
                    </div>
                  )}
                  {book.isBestSeller && (
                    <div className="absolute top-2 right-2 px-2 py-1 bg-[#d4af37] text-[#1a2332] text-xs font-bold rounded">
                      BEST SELLER
                    </div>
                  )}
                  
                  {/* Quick Add to Cart */}
                  <button
                    onClick={(e) => handleAddToCart(e, book)}
                    className={`absolute bottom-2 right-2 p-2 rounded-full transition-all opacity-0 group-hover:opacity-100 ${
                      justAdded || inCart
                        ? 'bg-green-500 text-white'
                        : 'bg-[#d4af37] text-[#1a2332] hover:bg-[#e5c04a]'
                    }`}
                  >
                    {justAdded ? (
                      <Check className="w-4 h-4" />
                    ) : inCart ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <ShoppingCart className="w-4 h-4" />
                    )}
                  </button>
                </div>
                <h4 className="font-semibold text-[#f5f1e8] text-sm line-clamp-1 group-hover:text-[#d4af37] transition-colors">
                  {book.title}
                </h4>
                <p className="text-[#f5f1e8]/50 text-xs line-clamp-1 mt-1">
                  {book.subtitle}
                </p>
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-[#d4af37] fill-[#d4af37]" />
                    <span className="text-[#f5f1e8]/50 text-xs">{book.rating}</span>
                  </div>
                  <span className="text-[#d4af37] text-sm font-semibold">${book.price.toFixed(2)}</span>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );

  return (
    <section className="py-20 bg-gradient-to-b from-[#1a2332] to-[#0f1520]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <p className="text-[#d4af37] text-sm font-medium uppercase tracking-wider mb-2">
            Explore by Topic
          </p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#f5f1e8] mb-4">
            Book <span className="text-[#d4af37]">Collections</span>
          </h2>
          <p className="text-[#f5f1e8]/60 max-w-2xl mx-auto">
            Explore books organized by theme. Each collection addresses specific areas of faith and life.
          </p>
        </div>

        {/* Series Rows */}
        <div className="space-y-12">
          <SeriesRow
            title="Faith Journey Series"
            description="Deepen your relationship with God through understanding His persistence and presence in your life."
            seriesBooks={faithJourneySeries}
            icon={BookOpen}
          />

          <SeriesRow
            title="Relationship Wisdom Series"
            description="Build stronger marriages and meaningful relationships with practical, faith-based guidance."
            seriesBooks={relationshipWisdomSeries}
            icon={Heart}
          />
        </div>

        {/* Reading Recommendation */}
        <div className="mt-16 bg-[#d4af37]/10 rounded-2xl p-8 border border-[#d4af37]/20">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8] mb-3">
                Not Sure Where to Start?
              </h3>
              <p className="text-[#f5f1e8]/70 mb-4">
                If you're new to my books, I recommend starting with "God's Persistence" - 
                it's the foundation for understanding God's unfailing love and sets the stage 
                for the other topics I explore in my writing.
              </p>
              <button 
                onClick={() => onSelectBook(1)}
                className="px-6 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-full hover:bg-[#e5c04a] transition-all"
              >
                Start with God's Persistence
              </button>
            </div>
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-[#d4af37]/20 rounded-xl blur-xl" />
                <div className="relative bg-[#1a2332] rounded-xl p-6 border border-[#d4af37]/30">
                  <p className="text-[#d4af37] text-sm font-medium mb-2">Recommended Start</p>
                  <p className="font-['Playfair_Display'] text-xl font-bold text-[#f5f1e8] mb-1">
                    God's Persistence
                  </p>
                  <p className="text-[#f5f1e8]/60 text-sm">
                    A Journey of Faith Through Trials and Triumphs
                  </p>
                  <p className="text-[#d4af37] font-bold mt-2">$9.99</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </section>
  );
};

export default SeriesShowcase;
