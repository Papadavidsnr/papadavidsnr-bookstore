import React, { useState } from 'react';
import { Star, ShoppingCart, Eye, Heart, Check, ExternalLink } from 'lucide-react';
import { Book } from '../data/booksData';
import { useCart } from '../contexts/CartContext';

interface BookCardProps {
  book: Book;
  onSelect: (bookId: number) => void;
  onAddToWishlist?: (bookId: number) => void;
  isWishlisted?: boolean;
}

const BookCard: React.FC<BookCardProps> = ({
  book,
  onSelect,
  onAddToWishlist,
  isWishlisted = false,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [showExcerpt, setShowExcerpt] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  
  const { addToCart, isInCart } = useCart();
  const inCart = isInCart(book.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(book);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 1500);
  };

  return (
    <div
      className="group relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setShowExcerpt(false);
      }}
    >
      {/* Card Container */}
      <div
        className={`relative bg-[#1a2332] rounded-xl overflow-hidden border border-[#f5f1e8]/10 transition-all duration-500 ${
          isHovered ? 'border-[#d4af37]/50 shadow-2xl shadow-[#d4af37]/10 transform -translate-y-2' : ''
        }`}
      >
        {/* Book Cover */}
        <div className="relative aspect-[3/4] overflow-hidden">
          <img
            src={book.coverImage}
            alt={book.title}
            className={`w-full h-full object-cover transition-transform duration-700 ${
              isHovered ? 'scale-110' : 'scale-100'
            }`}
          />
          
          {/* Overlay on Hover */}
          <div
            className={`absolute inset-0 bg-gradient-to-t from-[#1a2332] via-[#1a2332]/60 to-transparent transition-opacity duration-300 ${
              isHovered ? 'opacity-100' : 'opacity-0'
            }`}
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {book.isBestSeller && (
              <span className="px-2 py-1 bg-[#d4af37] text-[#1a2332] text-xs font-bold rounded">
                BEST SELLER
              </span>
            )}
            {book.featured && !book.isBestSeller && (
              <span className="px-2 py-1 bg-[#d4af37] text-[#1a2332] text-xs font-bold rounded">
                FEATURED
              </span>
            )}
            {book.series && (
              <span className="px-2 py-1 bg-[#1a2332]/80 text-[#f5f1e8] text-xs rounded backdrop-blur-sm">
                {book.series}
              </span>
            )}
          </div>

          {/* Wishlist Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToWishlist?.(book.id);
            }}
            className={`absolute top-3 right-3 p-2 rounded-full transition-all ${
              isWishlisted
                ? 'bg-[#d4af37] text-[#1a2332]'
                : 'bg-[#1a2332]/80 text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332]'
            }`}
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
          </button>

          {/* Added to Cart Notification */}
          {addedToCart && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#1a2332]/90 z-10 animate-fade-in">
              <div className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center animate-scale-in">
                  <Check className="w-6 h-6 text-white" />
                </div>
                <span className="text-[#f5f1e8] font-medium">Added to Cart!</span>
              </div>
            </div>
          )}

          {/* Quick Actions on Hover */}
          <div
            className={`absolute bottom-4 left-4 right-4 flex gap-2 transition-all duration-300 ${
              isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <button
              onClick={handleAddToCart}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 font-semibold rounded-lg transition-colors ${
                inCart
                  ? 'bg-green-500 text-white'
                  : 'bg-[#d4af37] text-[#1a2332] hover:bg-[#e5c04a]'
              }`}
            >
              {inCart ? (
                <>
                  <Check className="w-4 h-4" />
                  In Cart
                </>
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4" />
                  Add to Cart
                </>
              )}
            </button>
            <button
              onClick={() => setShowExcerpt(!showExcerpt)}
              className="p-2.5 bg-[#f5f1e8]/20 text-[#f5f1e8] rounded-lg hover:bg-[#f5f1e8]/30 transition-colors backdrop-blur-sm"
            >
              <Eye className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Book Info */}
        <div className="p-4 space-y-3">
          <div>
            <p className="text-[#d4af37] text-xs font-medium uppercase tracking-wider mb-1">
              {book.genre}
            </p>
            <h3
              onClick={() => onSelect(book.id)}
              className="font-['Playfair_Display'] text-lg font-bold text-[#f5f1e8] cursor-pointer hover:text-[#d4af37] transition-colors line-clamp-1"
            >
              {book.title}
            </h3>
            {book.subtitle && (
              <p className="text-[#f5f1e8]/50 text-xs mt-1 line-clamp-1">
                {book.subtitle}
              </p>
            )}
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.floor(book.rating)
                      ? 'text-[#d4af37] fill-[#d4af37]'
                      : 'text-[#f5f1e8]/20'
                  }`}
                />
              ))}
            </div>
            <span className="text-[#f5f1e8]/50 text-xs">
              {book.rating} ({book.reviewCount})
            </span>
          </div>

          {/* Price & Add to Cart */}
          <div className="flex items-center justify-between">
            <span className="text-xl font-bold text-[#f5f1e8]">
              ${book.price.toFixed(2)}
            </span>
            <button
              onClick={handleAddToCart}
              className={`p-2 rounded-lg transition-colors ${
                inCart
                  ? 'bg-green-500/20 text-green-400'
                  : 'bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a2332]'
              }`}
            >
              {inCart ? <Check className="w-4 h-4" /> : <ShoppingCart className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Excerpt Popup */}
      {showExcerpt && (
        <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-[#1a2332] border border-[#d4af37]/30 rounded-xl shadow-2xl">
          <h4 className="font-['Playfair_Display'] text-lg font-bold text-[#d4af37] mb-2">
            Excerpt
          </h4>
          <p className="text-[#f5f1e8]/80 text-sm italic leading-relaxed">
            "{book.excerpt}"
          </p>
          <div className="flex items-center justify-between mt-3">
            <button
              onClick={() => setShowExcerpt(false)}
              className="text-[#d4af37] text-sm hover:underline"
            >
              Close
            </button>
            <a
              href={book.amazonLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-[#f5f1e8]/60 text-sm hover:text-[#d4af37]"
            >
              View on Amazon <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scale-in {
          0% { transform: scale(0); }
          50% { transform: scale(1.2); }
          100% { transform: scale(1); }
        }
        .animate-fade-in {
          animation: fade-in 0.2s ease-out;
        }
        .animate-scale-in {
          animation: scale-in 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default BookCard;
