import React, { useState, useMemo } from 'react';
import { Search, Filter, Grid, List, SlidersHorizontal, ExternalLink } from 'lucide-react';
import { books, genres, series } from '../data/booksData';
import BookCard from './BookCard';

interface BookGridProps {
  onSelectBook: (bookId: number) => void;
  wishlist: number[];
  onToggleWishlist: (bookId: number) => void;
}

const BookGrid: React.FC<BookGridProps> = ({
  onSelectBook,
  wishlist,
  onToggleWishlist,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [selectedSeries, setSelectedSeries] = useState('All Series');
  const [sortBy, setSortBy] = useState<'newest' | 'rating' | 'price-low' | 'price-high'>('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredBooks = useMemo(() => {
    let result = [...books];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (book) =>
          book.title.toLowerCase().includes(query) ||
          book.synopsis.toLowerCase().includes(query) ||
          book.genre.toLowerCase().includes(query)
      );
    }

    // Genre filter
    if (selectedGenre !== 'All') {
      result = result.filter((book) => book.genre === selectedGenre);
    }

    // Series filter
    if (selectedSeries !== 'All Series') {
      if (selectedSeries === 'Standalone') {
        result = result.filter((book) => !book.series);
      } else {
        result = result.filter((book) => book.series === selectedSeries);
      }
    }

    // Sort
    switch (sortBy) {
      case 'newest':
        result.sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime());
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
    }

    return result;
  }, [searchQuery, selectedGenre, selectedSeries, sortBy]);

  return (
    <section id="books" className="py-20 bg-[#1a2332]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#f5f1e8] mb-4">
            My <span className="text-[#d4af37]">Books</span>
          </h2>
          <p className="text-[#f5f1e8]/60 max-w-2xl mx-auto">
            Explore my collection of faith-based books on spiritual growth, marriage, and relationships. 
            Each book is written to strengthen your faith and help you build deeper connections.
          </p>
          <a
            href="https://www.amazon.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 mt-4 text-[#d4af37] hover:underline"
          >
            <span>Available on Amazon KDP</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative max-w-xl mx-auto">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search books by title, genre, or keyword..."
              className="w-full px-5 py-4 pl-12 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-xl text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none focus:border-[#d4af37] transition-colors"
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#f5f1e8]/40" />
          </div>

          {/* Filter Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              {/* Genre Filter */}
              <div className="relative">
                <select
                  value={selectedGenre}
                  onChange={(e) => setSelectedGenre(e.target.value)}
                  className="appearance-none px-4 py-2.5 pr-10 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-lg text-[#f5f1e8] text-sm focus:outline-none focus:border-[#d4af37] cursor-pointer"
                >
                  {genres.map((genre) => (
                    <option key={genre} value={genre} className="bg-[#1a2332]">
                      {genre}
                    </option>
                  ))}
                </select>
                <Filter className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#f5f1e8]/40 pointer-events-none" />
              </div>

              {/* Series Filter */}
              <div className="relative">
                <select
                  value={selectedSeries}
                  onChange={(e) => setSelectedSeries(e.target.value)}
                  className="appearance-none px-4 py-2.5 pr-10 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-lg text-[#f5f1e8] text-sm focus:outline-none focus:border-[#d4af37] cursor-pointer"
                >
                  {series.map((s) => (
                    <option key={s} value={s} className="bg-[#1a2332]">
                      {s}
                    </option>
                  ))}
                </select>
                <Filter className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#f5f1e8]/40 pointer-events-none" />
              </div>

              {/* Sort */}
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                  className="appearance-none px-4 py-2.5 pr-10 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-lg text-[#f5f1e8] text-sm focus:outline-none focus:border-[#d4af37] cursor-pointer"
                >
                  <option value="newest" className="bg-[#1a2332]">Newest First</option>
                  <option value="rating" className="bg-[#1a2332]">Highest Rated</option>
                  <option value="price-low" className="bg-[#1a2332]">Price: Low to High</option>
                  <option value="price-high" className="bg-[#1a2332]">Price: High to Low</option>
                </select>
                <SlidersHorizontal className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#f5f1e8]/40 pointer-events-none" />
              </div>
            </div>

            {/* View Toggle */}
            <div className="flex items-center gap-2 bg-[#f5f1e8]/5 rounded-lg p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-[#d4af37] text-[#1a2332]'
                    : 'text-[#f5f1e8]/60 hover:text-[#f5f1e8]'
                }`}
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'list'
                    ? 'bg-[#d4af37] text-[#1a2332]'
                    : 'text-[#f5f1e8]/60 hover:text-[#f5f1e8]'
                }`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Results Count */}
          <div className="text-[#f5f1e8]/50 text-sm">
            Showing {filteredBooks.length} of {books.length} books
          </div>
        </div>

        {/* Books Grid */}
        {filteredBooks.length > 0 ? (
          <div
            className={
              viewMode === 'grid'
                ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
                : 'space-y-4'
            }
          >
            {filteredBooks.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                onSelect={onSelectBook}
                onAddToWishlist={onToggleWishlist}
                isWishlisted={wishlist.includes(book.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-[#f5f1e8]/60 text-lg">
              No books found matching your criteria.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedGenre('All');
                setSelectedSeries('All Series');
              }}
              className="mt-4 text-[#d4af37] hover:underline"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default BookGrid;
