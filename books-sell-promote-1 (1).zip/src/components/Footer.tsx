import React, { useState } from 'react';
import { BookOpen, Instagram, Twitter, Facebook, Youtube, Mail, MapPin, Heart, ExternalLink, Linkedin } from 'lucide-react';
import { books, socialLinks } from '../data/booksData';

// TikTok icon component
const TikTokIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
  </svg>
);

interface FooterProps {
  onNavigate: (section: string) => void;
  onSelectBook: (bookId: number) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate, onSelectBook }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleQuickSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { label: 'Home', section: 'home' },
    { label: 'Books', section: 'books' },
    { label: 'About', section: 'about' },
    { label: 'Blog', section: 'blog' },
    { label: 'Events', section: 'events' },
    { label: 'Contact', section: 'contact' },
  ];

  const legalLinks = [
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
  ];

  return (
    <footer className="bg-[#0f1520] pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 pb-12 border-b border-[#f5f1e8]/10">
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <BookOpen className="w-8 h-8 text-[#d4af37]" />
              <div className="flex flex-col">
                <span className="font-['Playfair_Display'] text-xl font-bold text-[#f5f1e8]">
                  PapaDavidSnr
                </span>
                <span className="text-[#d4af37] text-sm font-medium -mt-1">
                  Bookstore
                </span>
              </div>
            </div>
            <p className="text-[#f5f1e8]/60 leading-relaxed">
              Faith-based books on spiritual growth, marriage, and relationships 
              by David Anane Nyarko (Papa David Snr.). Available on Amazon KDP.
            </p>
            
            {/* Social Links */}
            <div className="flex flex-wrap gap-3">
              <a
                href={socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                title="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href={socialLinks.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                title="X (Twitter)"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href={socialLinks.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                title="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href={socialLinks.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                title="TikTok"
              >
                <TikTokIcon className="w-5 h-5" />
              </a>
              <a
                href={socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 bg-[#f5f1e8]/10 rounded-full text-[#f5f1e8] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                title="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-['Playfair_Display'] text-lg font-bold text-[#f5f1e8] mb-6">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.section}>
                  <button
                    onClick={() => onNavigate(link.section)}
                    className="text-[#f5f1e8]/60 hover:text-[#d4af37] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Books */}
          <div>
            <h4 className="font-['Playfair_Display'] text-lg font-bold text-[#f5f1e8] mb-6">
              My Books
            </h4>
            <ul className="space-y-3">
              {books.map((book) => (
                <li key={book.id}>
                  <button
                    onClick={() => onSelectBook(book.id)}
                    className="text-[#f5f1e8]/60 hover:text-[#d4af37] transition-colors flex items-center gap-2 text-left"
                  >
                    <span className="line-clamp-1">{book.title}</span>
                    <span className="text-[#d4af37] text-sm">${book.price.toFixed(2)}</span>
                  </button>
                </li>
              ))}
              <li>
                <a
                  href="https://www.amazon.com/s?k=David+Anane+Nyarko"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#d4af37] hover:underline text-sm mt-2 flex items-center gap-1"
                >
                  View on Amazon <ExternalLink className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div className="space-y-6">
            <div>
              <h4 className="font-['Playfair_Display'] text-lg font-bold text-[#f5f1e8] mb-6">
                Get in Touch
              </h4>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-[#f5f1e8]/60">
                  <Mail className="w-5 h-5 text-[#d4af37]" />
                  <a href={`mailto:${socialLinks.email}`} className="hover:text-[#d4af37] transition-colors">
                    {socialLinks.email}
                  </a>
                </li>
                <li className="flex items-center gap-3 text-[#f5f1e8]/60">
                  <MapPin className="w-5 h-5 text-[#d4af37]" />
                  <span>Ghana, West Africa</span>
                </li>
              </ul>
            </div>

            {/* Quick Newsletter */}
            <div>
              <h5 className="text-[#f5f1e8] font-medium mb-3">Stay Updated</h5>
              {!subscribed ? (
                <form onSubmit={handleQuickSubscribe} className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Your email"
                    className="flex-1 px-4 py-2 bg-[#f5f1e8]/10 border border-[#f5f1e8]/20 rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 text-sm focus:outline-none focus:border-[#d4af37]"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#d4af37] text-[#1a2332] font-medium rounded-lg hover:bg-[#e5c04a] transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <p className="text-[#d4af37] text-sm">Thanks for subscribing! God bless you.</p>
              )}
            </div>

            {/* Support via PayPal */}
            <div>
              <h5 className="text-[#f5f1e8] font-medium mb-2">Support My Ministry</h5>
              <a
                href={`https://www.paypal.com/paypalme/${socialLinks.paypal.replace('@', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-[#f5f1e8]/60 hover:text-[#d4af37] transition-colors text-sm"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 3.72a.77.77 0 0 1 .757-.629h6.724c2.228 0 3.947.512 5.105 1.521 1.198 1.044 1.678 2.588 1.428 4.59-.273 2.183-1.196 3.925-2.74 5.18-1.5 1.218-3.51 1.836-5.975 1.836H8.21a.77.77 0 0 0-.757.629l-.377 2.49z"/>
                  <path d="M19.867 7.057c-.273 2.183-1.196 3.925-2.74 5.18-1.5 1.218-3.51 1.836-5.975 1.836H9.12a.77.77 0 0 0-.757.629l-.936 5.935a.641.641 0 0 0 .633.74h3.566a.77.77 0 0 0 .757-.629l.377-2.49a.77.77 0 0 1 .757-.629h2.032c2.465 0 4.475-.618 5.975-1.836 1.544-1.255 2.467-2.997 2.74-5.18.25-2.002-.23-3.546-1.428-4.59-.138-.12-.284-.233-.437-.34.152.107.298.22.437.34 1.198 1.044 1.678 2.588 1.428 4.59z" opacity=".35"/>
                </svg>
                PayPal: {socialLinks.paypal}
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[#f5f1e8]/40 text-sm">
            © {currentYear} PapaDavidSnr Bookstore. All rights reserved.
          </p>

          {/* Legal Links */}
          <div className="flex flex-wrap items-center gap-6">
            {legalLinks.map((link, index) => (
              <a
                key={index}
                href={link.href}
                className="text-[#f5f1e8]/40 text-sm hover:text-[#d4af37] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          <p className="text-[#f5f1e8]/40 text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-[#d4af37] fill-[#d4af37]" /> for readers everywhere
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
