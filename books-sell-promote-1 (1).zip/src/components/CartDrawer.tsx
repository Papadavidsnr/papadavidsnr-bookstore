import React, { useState } from 'react';
import { X, Minus, Plus, Trash2, ShoppingBag, ArrowRight, CreditCard, Truck, Check, Loader2 } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

type CheckoutStep = 'cart' | 'shipping' | 'payment' | 'confirmation';

interface ShippingInfo {
  firstName: string;
  lastName: string;
  email: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose }) => {
  const { items, removeFromCart, updateQuantity, getSubtotal, clearCart, getItemCount } = useCart();
  const [currentStep, setCurrentStep] = useState<CheckoutStep>('cart');
  const [isProcessing, setIsProcessing] = useState(false);
  const [shippingInfo, setShippingInfo] = useState<ShippingInfo>({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'United States',
  });
  const [errors, setErrors] = useState<Partial<ShippingInfo>>({});

  const subtotal = getSubtotal();
  const shipping = subtotal > 50 ? 0 : 4.99;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  const validateShipping = () => {
    const newErrors: Partial<ShippingInfo> = {};
    
    if (!shippingInfo.firstName.trim()) newErrors.firstName = 'Required';
    if (!shippingInfo.lastName.trim()) newErrors.lastName = 'Required';
    if (!shippingInfo.email.trim()) {
      newErrors.email = 'Required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(shippingInfo.email)) {
      newErrors.email = 'Invalid email';
    }
    if (!shippingInfo.address.trim()) newErrors.address = 'Required';
    if (!shippingInfo.city.trim()) newErrors.city = 'Required';
    if (!shippingInfo.state.trim()) newErrors.state = 'Required';
    if (!shippingInfo.zipCode.trim()) newErrors.zipCode = 'Required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleProceedToShipping = () => {
    if (items.length > 0) {
      setCurrentStep('shipping');
    }
  };

  const handleProceedToPayment = () => {
    if (validateShipping()) {
      setCurrentStep('payment');
    }
  };

  const handlePlaceOrder = async () => {
    setIsProcessing(true);
    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsProcessing(false);
    setCurrentStep('confirmation');
    clearCart();
  };

  const handleClose = () => {
    if (currentStep === 'confirmation') {
      setCurrentStep('cart');
    }
    onClose();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setShippingInfo((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof ShippingInfo]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={handleClose}
      />

      {/* Drawer */}
      <div className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-[#1a2332] shadow-2xl flex flex-col animate-slide-in-right">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#f5f1e8]/10">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-6 h-6 text-[#d4af37]" />
            <h2 className="font-['Playfair_Display'] text-xl font-bold text-[#f5f1e8]">
              {currentStep === 'cart' && 'Shopping Cart'}
              {currentStep === 'shipping' && 'Shipping Information'}
              {currentStep === 'payment' && 'Payment'}
              {currentStep === 'confirmation' && 'Order Confirmed'}
            </h2>
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-[#f5f1e8]/60 hover:text-[#f5f1e8] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Steps */}
        {currentStep !== 'confirmation' && (
          <div className="px-6 py-4 border-b border-[#f5f1e8]/10">
            <div className="flex items-center justify-between">
              {['cart', 'shipping', 'payment'].map((step, index) => (
                <React.Fragment key={step}>
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                        currentStep === step
                          ? 'bg-[#d4af37] text-[#1a2332]'
                          : ['cart', 'shipping', 'payment'].indexOf(currentStep) > index
                          ? 'bg-green-500 text-white'
                          : 'bg-[#f5f1e8]/10 text-[#f5f1e8]/50'
                      }`}
                    >
                      {['cart', 'shipping', 'payment'].indexOf(currentStep) > index ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        index + 1
                      )}
                    </div>
                    <span className={`text-sm hidden sm:block ${
                      currentStep === step ? 'text-[#d4af37]' : 'text-[#f5f1e8]/50'
                    }`}>
                      {step.charAt(0).toUpperCase() + step.slice(1)}
                    </span>
                  </div>
                  {index < 2 && (
                    <div className="flex-1 h-px bg-[#f5f1e8]/10 mx-2" />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {/* Cart Items */}
          {currentStep === 'cart' && (
            <div className="p-6">
              {items.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag className="w-16 h-16 text-[#f5f1e8]/20 mx-auto mb-4" />
                  <p className="text-[#f5f1e8]/60 mb-4">Your cart is empty</p>
                  <button
                    onClick={handleClose}
                    className="text-[#d4af37] hover:underline"
                  >
                    Continue Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {items.map((item) => (
                    <div
                      key={item.book.id}
                      className="flex gap-4 p-4 bg-[#f5f1e8]/5 rounded-xl border border-[#f5f1e8]/10"
                    >
                      <img
                        src={item.book.coverImage}
                        alt={item.book.title}
                        className="w-20 h-28 object-cover rounded-lg"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-[#f5f1e8] line-clamp-1">
                          {item.book.title}
                        </h3>
                        <p className="text-[#f5f1e8]/50 text-sm">{item.book.genre}</p>
                        <p className="text-[#d4af37] font-semibold mt-1">
                          ${item.book.price.toFixed(2)}
                        </p>
                        
                        {/* Quantity Controls */}
                        <div className="flex items-center gap-3 mt-2">
                          <div className="flex items-center bg-[#1a2332] rounded-lg border border-[#f5f1e8]/10">
                            <button
                              onClick={() => updateQuantity(item.book.id, item.quantity - 1)}
                              className="p-2 text-[#f5f1e8]/60 hover:text-[#f5f1e8] transition-colors"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="px-3 text-[#f5f1e8] font-medium">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.book.id, item.quantity + 1)}
                              className="p-2 text-[#f5f1e8]/60 hover:text-[#f5f1e8] transition-colors"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                          <button
                            onClick={() => removeFromCart(item.book.id)}
                            className="p-2 text-red-400 hover:text-red-300 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-[#f5f1e8] font-semibold">
                          ${(item.book.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Shipping Form */}
          {currentStep === 'shipping' && (
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#f5f1e8]/70 text-sm mb-1">First Name *</label>
                  <input
                    type="text"
                    name="firstName"
                    value={shippingInfo.firstName}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-[#f5f1e8]/5 border rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] ${
                      errors.firstName ? 'border-red-500' : 'border-[#f5f1e8]/10'
                    }`}
                  />
                  {errors.firstName && <p className="text-red-400 text-xs mt-1">{errors.firstName}</p>}
                </div>
                <div>
                  <label className="block text-[#f5f1e8]/70 text-sm mb-1">Last Name *</label>
                  <input
                    type="text"
                    name="lastName"
                    value={shippingInfo.lastName}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-[#f5f1e8]/5 border rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] ${
                      errors.lastName ? 'border-red-500' : 'border-[#f5f1e8]/10'
                    }`}
                  />
                  {errors.lastName && <p className="text-red-400 text-xs mt-1">{errors.lastName}</p>}
                </div>
              </div>

              <div>
                <label className="block text-[#f5f1e8]/70 text-sm mb-1">Email *</label>
                <input
                  type="email"
                  name="email"
                  value={shippingInfo.email}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-2.5 bg-[#f5f1e8]/5 border rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] ${
                    errors.email ? 'border-red-500' : 'border-[#f5f1e8]/10'
                  }`}
                />
                {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-[#f5f1e8]/70 text-sm mb-1">Address *</label>
                <input
                  type="text"
                  name="address"
                  value={shippingInfo.address}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-2.5 bg-[#f5f1e8]/5 border rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] ${
                    errors.address ? 'border-red-500' : 'border-[#f5f1e8]/10'
                  }`}
                />
                {errors.address && <p className="text-red-400 text-xs mt-1">{errors.address}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#f5f1e8]/70 text-sm mb-1">City *</label>
                  <input
                    type="text"
                    name="city"
                    value={shippingInfo.city}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-[#f5f1e8]/5 border rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] ${
                      errors.city ? 'border-red-500' : 'border-[#f5f1e8]/10'
                    }`}
                  />
                  {errors.city && <p className="text-red-400 text-xs mt-1">{errors.city}</p>}
                </div>
                <div>
                  <label className="block text-[#f5f1e8]/70 text-sm mb-1">State *</label>
                  <input
                    type="text"
                    name="state"
                    value={shippingInfo.state}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-[#f5f1e8]/5 border rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] ${
                      errors.state ? 'border-red-500' : 'border-[#f5f1e8]/10'
                    }`}
                  />
                  {errors.state && <p className="text-red-400 text-xs mt-1">{errors.state}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[#f5f1e8]/70 text-sm mb-1">ZIP Code *</label>
                  <input
                    type="text"
                    name="zipCode"
                    value={shippingInfo.zipCode}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-[#f5f1e8]/5 border rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] ${
                      errors.zipCode ? 'border-red-500' : 'border-[#f5f1e8]/10'
                    }`}
                  />
                  {errors.zipCode && <p className="text-red-400 text-xs mt-1">{errors.zipCode}</p>}
                </div>
                <div>
                  <label className="block text-[#f5f1e8]/70 text-sm mb-1">Country</label>
                  <select
                    name="country"
                    value={shippingInfo.country}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37]"
                  >
                    <option value="United States">United States</option>
                    <option value="Canada">Canada</option>
                    <option value="United Kingdom">United Kingdom</option>
                  </select>
                </div>
              </div>

              {/* Shipping Info */}
              <div className="mt-6 p-4 bg-[#d4af37]/10 rounded-xl border border-[#d4af37]/20">
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-[#d4af37]" />
                  <div>
                    <p className="text-[#f5f1e8] font-medium">Free Shipping on orders over $50</p>
                    <p className="text-[#f5f1e8]/60 text-sm">Standard delivery: 5-7 business days</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Payment */}
          {currentStep === 'payment' && (
            <div className="p-6 space-y-6">
              <div className="p-4 bg-[#f5f1e8]/5 rounded-xl border border-[#f5f1e8]/10">
                <h3 className="text-[#f5f1e8] font-medium mb-3">Shipping To:</h3>
                <p className="text-[#f5f1e8]/70 text-sm">
                  {shippingInfo.firstName} {shippingInfo.lastName}<br />
                  {shippingInfo.address}<br />
                  {shippingInfo.city}, {shippingInfo.state} {shippingInfo.zipCode}<br />
                  {shippingInfo.country}
                </p>
                <button
                  onClick={() => setCurrentStep('shipping')}
                  className="text-[#d4af37] text-sm mt-2 hover:underline"
                >
                  Edit
                </button>
              </div>

              <div>
                <h3 className="text-[#f5f1e8] font-medium mb-3 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-[#d4af37]" />
                  Payment Method
                </h3>
                <div className="space-y-3">
                  <div className="p-4 bg-[#f5f1e8]/5 rounded-xl border-2 border-[#d4af37] cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded-full border-2 border-[#d4af37] flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-[#d4af37]" />
                      </div>
                      <span className="text-[#f5f1e8]">Credit / Debit Card</span>
                    </div>
                  </div>
                  
                  <div className="space-y-3 pl-7">
                    <input
                      type="text"
                      placeholder="Card Number"
                      className="w-full px-4 py-2.5 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none focus:border-[#d4af37]"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="MM/YY"
                        className="w-full px-4 py-2.5 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none focus:border-[#d4af37]"
                      />
                      <input
                        type="text"
                        placeholder="CVC"
                        className="w-full px-4 py-2.5 bg-[#f5f1e8]/5 border border-[#f5f1e8]/10 rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none focus:border-[#d4af37]"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-[#f5f1e8]/40 text-xs text-center">
                This is a demo checkout. No real payment will be processed.
              </p>
            </div>
          )}

          {/* Confirmation */}
          {currentStep === 'confirmation' && (
            <div className="p-6 text-center py-12">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Check className="w-10 h-10 text-green-500" />
              </div>
              <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8] mb-2">
                Thank You for Your Order!
              </h3>
              <p className="text-[#f5f1e8]/60 mb-6">
                Your order has been placed successfully. You'll receive a confirmation email shortly.
              </p>
              <div className="p-4 bg-[#f5f1e8]/5 rounded-xl border border-[#f5f1e8]/10 text-left mb-6">
                <p className="text-[#f5f1e8]/50 text-sm">Order Number</p>
                <p className="text-[#d4af37] font-mono font-bold">
                  #ORD-{Math.random().toString(36).substr(2, 9).toUpperCase()}
                </p>
              </div>
              <button
                onClick={handleClose}
                className="px-8 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-full hover:bg-[#e5c04a] transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        {currentStep !== 'confirmation' && items.length > 0 && (
          <div className="border-t border-[#f5f1e8]/10 p-6 space-y-4">
            {/* Order Summary */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-[#f5f1e8]/70">
                <span>Subtotal ({getItemCount()} items)</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#f5f1e8]/70">
                <span>Shipping</span>
                <span>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-[#f5f1e8]/70">
                <span>Estimated Tax</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#f5f1e8] font-bold text-lg pt-2 border-t border-[#f5f1e8]/10">
                <span>Total</span>
                <span className="text-[#d4af37]">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Action Button */}
            {currentStep === 'cart' && (
              <button
                onClick={handleProceedToShipping}
                className="w-full py-4 bg-[#d4af37] text-[#1a2332] font-semibold rounded-xl hover:bg-[#e5c04a] transition-colors flex items-center justify-center gap-2"
              >
                Proceed to Checkout
                <ArrowRight className="w-5 h-5" />
              </button>
            )}

            {currentStep === 'shipping' && (
              <div className="flex gap-3">
                <button
                  onClick={() => setCurrentStep('cart')}
                  className="flex-1 py-3 border border-[#f5f1e8]/20 text-[#f5f1e8] font-semibold rounded-xl hover:border-[#f5f1e8]/40 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleProceedToPayment}
                  className="flex-1 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-xl hover:bg-[#e5c04a] transition-colors flex items-center justify-center gap-2"
                >
                  Continue
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {currentStep === 'payment' && (
              <div className="flex gap-3">
                <button
                  onClick={() => setCurrentStep('shipping')}
                  className="flex-1 py-3 border border-[#f5f1e8]/20 text-[#f5f1e8] font-semibold rounded-xl hover:border-[#f5f1e8]/40 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handlePlaceOrder}
                  disabled={isProcessing}
                  className="flex-1 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-xl hover:bg-[#e5c04a] transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      Place Order
                      <Check className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`
        @keyframes slide-in-right {
          from {
            transform: translateX(100%);
          }
          to {
            transform: translateX(0);
          }
        }
        .animate-slide-in-right {
          animation: slide-in-right 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default CartDrawer;
