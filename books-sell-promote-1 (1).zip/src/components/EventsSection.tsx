import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Users, ExternalLink, Video, Mic, BookOpen, Ticket } from 'lucide-react';
import { events } from '../data/booksData';

const EventsSection: React.FC = () => {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [registeredEvents, setRegisteredEvents] = useState<number[]>([]);

  const eventTypes = [
    { id: 'all', label: 'All Events' },
    { id: 'signing', label: 'Book Signings' },
    { id: 'virtual', label: 'Virtual Events' },
    { id: 'speaking', label: 'Speaking' },
    { id: 'festival', label: 'Conferences' },
  ];

  const filteredEvents =
    selectedType === 'all'
      ? events
      : events.filter((event) => event.type === selectedType);

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'signing':
        return BookOpen;
      case 'reading':
        return Mic;
      case 'virtual':
        return Video;
      case 'speaking':
        return Mic;
      case 'festival':
        return Users;
      default:
        return Calendar;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const handleRegister = (eventId: number) => {
    if (registeredEvents.includes(eventId)) {
      setRegisteredEvents(registeredEvents.filter((id) => id !== eventId));
    } else {
      setRegisteredEvents([...registeredEvents, eventId]);
    }
  };

  const isUpcoming = (dateString: string) => {
    return new Date(dateString) >= new Date();
  };

  return (
    <section id="events" className="py-20 bg-gradient-to-b from-[#0f1520] to-[#1a2332]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <p className="text-[#d4af37] text-sm font-medium uppercase tracking-wider mb-2">
            Meet Papa David Snr.
          </p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#f5f1e8] mb-4">
            Upcoming <span className="text-[#d4af37]">Events</span>
          </h2>
          <p className="text-[#f5f1e8]/60 max-w-2xl mx-auto">
            Join me at book signings, workshops, and speaking engagements. I'd love to connect with you in person or virtually!
          </p>
        </div>

        {/* Event Type Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {eventTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedType === type.id
                  ? 'bg-[#d4af37] text-[#1a2332]'
                  : 'bg-[#f5f1e8]/10 text-[#f5f1e8]/70 hover:bg-[#f5f1e8]/20'
              }`}
            >
              {type.label}
            </button>
          ))}
        </div>

        {/* Events List */}
        <div className="space-y-6">
          {filteredEvents.map((event) => {
            const Icon = getEventIcon(event.type);
            const upcoming = isUpcoming(event.date);
            const isRegistered = registeredEvents.includes(event.id);

            return (
              <div
                key={event.id}
                className={`group relative bg-[#f5f1e8]/5 rounded-2xl overflow-hidden border transition-all ${
                  upcoming
                    ? 'border-[#f5f1e8]/10 hover:border-[#d4af37]/30'
                    : 'border-[#f5f1e8]/5 opacity-60'
                }`}
              >
                <div className="grid md:grid-cols-[auto,1fr,auto] gap-6 p-6">
                  {/* Date Badge */}
                  <div className="flex md:flex-col items-center gap-4 md:gap-2 md:w-24 text-center">
                    <div className="bg-[#d4af37]/20 rounded-xl p-4 md:w-full">
                      <div className="text-[#d4af37] text-3xl font-bold">
                        {new Date(event.date).getDate()}
                      </div>
                      <div className="text-[#f5f1e8]/60 text-sm uppercase">
                        {new Date(event.date).toLocaleDateString('en-US', { month: 'short' })}
                      </div>
                    </div>
                    <div className="md:hidden flex-1">
                      <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#f5f1e8]">
                        {event.title}
                      </h3>
                    </div>
                  </div>

                  {/* Event Details */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
                          event.type === 'virtual'
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'bg-[#d4af37]/20 text-[#d4af37]'
                        }`}
                      >
                        <Icon className="w-3 h-3" />
                        {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                      </span>
                      {!event.isFree && (
                        <span className="px-3 py-1 bg-[#f5f1e8]/10 text-[#f5f1e8]/60 text-xs rounded-full">
                          Ticketed Event
                        </span>
                      )}
                      {event.isFree && (
                        <span className="px-3 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                          Free Entry
                        </span>
                      )}
                    </div>

                    <h3 className="hidden md:block font-['Playfair_Display'] text-xl font-bold text-[#f5f1e8] group-hover:text-[#d4af37] transition-colors">
                      {event.title}
                    </h3>

                    <p className="text-[#f5f1e8]/60 text-sm">
                      {event.description}
                    </p>

                    <div className="flex flex-wrap gap-4 text-sm text-[#f5f1e8]/50">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {event.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {event.location}
                      </span>
                      {event.spotsLeft && (
                        <span className="flex items-center gap-1 text-[#d4af37]">
                          <Users className="w-4 h-4" />
                          {event.spotsLeft} spots left
                        </span>
                      )}
                    </div>

                    {event.address && (
                      <p className="text-[#f5f1e8]/40 text-xs">
                        {event.address}
                      </p>
                    )}
                  </div>

                  {/* Action Button */}
                  <div className="flex items-center">
                    {upcoming && event.registrationLink ? (
                      <button
                        onClick={() => handleRegister(event.id)}
                        className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all ${
                          isRegistered
                            ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                            : 'bg-[#d4af37] text-[#1a2332] hover:bg-[#e5c04a]'
                        }`}
                      >
                        {isRegistered ? (
                          <>
                            Registered
                            <Ticket className="w-4 h-4" />
                          </>
                        ) : (
                          <>
                            Register
                            <ExternalLink className="w-4 h-4" />
                          </>
                        )}
                      </button>
                    ) : (
                      <span className="text-[#f5f1e8]/40 text-sm">
                        {upcoming ? 'Details coming soon' : 'Past event'}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* No Events Message */}
        {filteredEvents.length === 0 && (
          <div className="text-center py-12">
            <p className="text-[#f5f1e8]/60">
              No events found for this category. Check back soon!
            </p>
          </div>
        )}

        {/* Newsletter CTA */}
        <div className="mt-16 text-center bg-[#d4af37]/10 rounded-2xl p-8 border border-[#d4af37]/20">
          <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8] mb-2">
            Never Miss an Event
          </h3>
          <p className="text-[#f5f1e8]/60 mb-6">
            Subscribe to get notified about upcoming events, book launches, and speaking engagements.
          </p>
          <button className="px-8 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-full hover:bg-[#e5c04a] transition-all">
            Subscribe Now
          </button>
        </div>
      </div>
    </section>
  );
};

export default EventsSection;
