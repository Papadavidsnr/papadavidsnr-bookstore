import React, { useState, useEffect } from 'react';
import { Menu, X, BookOpen, Search, ShoppingCart } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface HeaderProps {
  onNavigate: (section: string) => void;
  currentSection: string;
  onOpenCart: () => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate, currentSection, onOpenCart }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [cartBounce, setCartBounce] = useState(false);
  
  const { getItemCount } = useCart();
  const itemCount = getItemCount();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Animate cart icon when items change
  useEffect(() => {
    if (itemCount > 0) {
      setCartBounce(true);
      const timer = setTimeout(() => setCartBounce(false), 300);
      return () => clearTimeout(timer);
    }
  }, [itemCount]);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'books', label: 'Books' },
    { id: 'about', label: 'About' },
    { id: 'blog', label: 'Blog' },
    { id: 'events', label: 'Events' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (section: string) => {
    onNavigate(section);
    setIsMenuOpen(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('books');
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#1a2332]/95 backdrop-blur-md shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 group"
          >
            <BookOpen className="w-8 h-8 text-[#d4af37] group-hover:scale-110 transition-transform" />
            <div className="flex flex-col items-start">
              <span className="font-['Playfair_Display'] text-xl sm:text-2xl font-bold text-[#f5f1e8] leading-tight">
                PapaDavidSnr
              </span>
              <span className="text-[#d4af37] text-xs sm:text-sm font-medium -mt-1">
                Bookstore
              </span>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`relative text-sm font-medium tracking-wide transition-colors ${
                  currentSection === item.id
                    ? 'text-[#d4af37]'
                    : 'text-[#f5f1e8]/80 hover:text-[#f5f1e8]'
                }`}
              >
                {item.label}
                {currentSection === item.id && (
                  <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#d4af37]" />
                )}
              </button>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center gap-4">
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2 text-[#f5f1e8]/80 hover:text-[#d4af37] transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
            
            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className={`relative p-2 text-[#f5f1e8]/80 hover:text-[#d4af37] transition-all ${
                cartBounce ? 'scale-125' : 'scale-100'
              }`}
            >
              <ShoppingCart className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#d4af37] text-[#1a2332] text-xs font-bold rounded-full flex items-center justify-center animate-scale-in">
                  {itemCount > 9 ? '9+' : itemCount}
                </span>
              )}
            </button>
            
            <button
              onClick={() => handleNavClick('books')}
              className="px-6 py-2.5 bg-[#d4af37] text-[#1a2332] font-semibold rounded-full hover:bg-[#e5c04a] transition-all hover:shadow-lg hover:shadow-[#d4af37]/20"
            >
              Shop Books
            </button>
          </div>

          {/* Mobile Actions */}
          <div className="flex lg:hidden items-center gap-2">
            {/* Mobile Cart Button */}
            <button
              onClick={onOpenCart}
              className={`relative p-2 text-[#f5f1e8] transition-all ${
                cartBounce ? 'scale-125' : 'scale-100'
              }`}
            >
              <ShoppingCart className="w-6 h-6" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#d4af37] text-[#1a2332] text-xs font-bold rounded-full flex items-center justify-center">
                  {itemCount > 9 ? '9+' : itemCount}
                </span>
              )}
            </button>
            
            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-[#f5f1e8]"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {isSearchOpen && (
          <div className="hidden lg:block pb-4">
            <form onSubmit={handleSearch} className="relative max-w-md mx-auto">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search books, blog posts..."
                className="w-full px-4 py-3 pl-12 bg-[#f5f1e8]/10 border border-[#f5f1e8]/20 rounded-full text-[#f5f1e8] placeholder-[#f5f1e8]/50 focus:outline-none focus:border-[#d4af37]"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#f5f1e8]/50" />
            </form>
          </div>
        )}
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-[#1a2332]/98 backdrop-blur-md border-t border-[#f5f1e8]/10">
          <nav className="max-w-7xl mx-auto px-4 py-6 space-y-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`block w-full text-left py-2 text-lg font-medium ${
                  currentSection === item.id
                    ? 'text-[#d4af37]'
                    : 'text-[#f5f1e8]/80'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => handleNavClick('books')}
              className="w-full mt-4 px-6 py-3 bg-[#d4af37] text-[#1a2332] font-semibold rounded-full"
            >
              Shop Books
            </button>
          </nav>
        </div>
      )}

      <style>{`
        @keyframes scale-in {
          0% {
            transform: scale(0);
          }
          50% {
            transform: scale(1.2);
          }
          100% {
            transform: scale(1);
          }
        }
        .animate-scale-in {
          animation: scale-in 0.3s ease-out;
        }
      `}</style>
    </header>
  );
};

export default Header;
