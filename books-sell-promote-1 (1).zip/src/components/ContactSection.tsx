import React, { useState } from 'react';
import { Mail, Send, User, MessageSquare, BookOpen, Loader2, Check, AlertCircle, MapPin, Instagram, Facebook, Twitter, Linkedin } from 'lucide-react';
import { socialLinks } from '../data/booksData';

// TikTok icon component
const TikTokIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
  </svg>
);

const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    inquiryType: 'general',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const inquiryTypes = [
    { value: 'general', label: 'General Inquiry' },
    { value: 'prayer', label: 'Prayer Request' },
    { value: 'speaking', label: 'Speaking Engagement' },
    { value: 'bookclub', label: 'Book Club Visit' },
    { value: 'bulk', label: 'Bulk Orders' },
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!formData.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (formData.message.length < 20) {
      newErrors.message = 'Message must be at least 20 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);
    setSubmitStatus('idle');

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setIsSubmitting(false);
    setSubmitStatus('success');
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: '',
      inquiryType: 'general',
    });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <section id="contact" className="py-20 bg-[#1a2332]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Info Side */}
          <div className="space-y-8">
            <div>
              <p className="text-[#d4af37] text-sm font-medium uppercase tracking-wider mb-2">
                Get in Touch
              </p>
              <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-[#f5f1e8] mb-4">
                Let's <span className="text-[#d4af37]">Connect</span>
              </h2>
              <p className="text-[#f5f1e8]/60 leading-relaxed">
                Whether you're interested in a speaking engagement, have a prayer request, 
                want to discuss bulk orders, or just want to share how my books have blessed you, 
                I'd love to hear from you.
              </p>
            </div>

            {/* Contact Cards */}
            <div className="space-y-4">
              <div className="bg-[#f5f1e8]/5 rounded-xl p-6 border border-[#f5f1e8]/10">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-[#d4af37]/20 rounded-lg">
                    <Mail className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-[#f5f1e8] font-semibold mb-1">Email</h3>
                    <p className="text-[#f5f1e8]/60 text-sm mb-2">
                      For general inquiries and testimonies
                    </p>
                    <a
                      href={`mailto:${socialLinks.email}`}
                      className="text-[#d4af37] hover:underline"
                    >
                      {socialLinks.email}
                    </a>
                  </div>
                </div>
              </div>

              <div className="bg-[#f5f1e8]/5 rounded-xl p-6 border border-[#f5f1e8]/10">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-[#d4af37]/20 rounded-lg">
                    <MapPin className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-[#f5f1e8] font-semibold mb-1">Location</h3>
                    <p className="text-[#f5f1e8]/60 text-sm mb-2">
                      Based in Ghana, West Africa
                    </p>
                    <p className="text-[#d4af37]">
                      Available for virtual & in-person events
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-[#f5f1e8]/5 rounded-xl p-6 border border-[#f5f1e8]/10">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-[#d4af37]/20 rounded-lg">
                    <BookOpen className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-[#f5f1e8] font-semibold mb-1">Books on Amazon</h3>
                    <p className="text-[#f5f1e8]/60 text-sm mb-2">
                      All books available on Amazon KDP
                    </p>
                    <a
                      href="https://www.amazon.com/s?k=David+Anane+Nyarko"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#d4af37] hover:underline"
                    >
                      View on Amazon
                    </a>
                  </div>
                </div>
              </div>

              {/* Social Media Links */}
              <div className="bg-[#f5f1e8]/5 rounded-xl p-6 border border-[#f5f1e8]/10">
                <h3 className="text-[#f5f1e8] font-semibold mb-4">Follow Me</h3>
                <div className="flex flex-wrap gap-3">
                  <a
                    href={socialLinks.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-[#d4af37]/20 rounded-lg text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                    title="Instagram"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                  <a
                    href={socialLinks.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-[#d4af37]/20 rounded-lg text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                    title="Facebook"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                  <a
                    href={socialLinks.twitter}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-[#d4af37]/20 rounded-lg text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                    title="X (Twitter)"
                  >
                    <Twitter className="w-5 h-5" />
                  </a>
                  <a
                    href={socialLinks.tiktok}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-[#d4af37]/20 rounded-lg text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                    title="TikTok"
                  >
                    <TikTokIcon className="w-5 h-5" />
                  </a>
                  <a
                    href={socialLinks.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-[#d4af37]/20 rounded-lg text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a2332] transition-colors"
                    title="LinkedIn"
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                </div>
              </div>

              <div className="bg-[#f5f1e8]/5 rounded-xl p-6 border border-[#f5f1e8]/10">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-[#d4af37]/20 rounded-lg">
                    <MessageSquare className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-[#f5f1e8] font-semibold mb-1">Response Time</h3>
                    <p className="text-[#f5f1e8]/60 text-sm">
                      I personally read every message and aim to respond within 3-5 business days. 
                      Your message matters to me!
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Form Side */}
          <div className="bg-[#f5f1e8]/5 rounded-2xl p-8 border border-[#f5f1e8]/10">
            {submitStatus === 'success' ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-20 h-20 bg-[#d4af37]/20 rounded-full flex items-center justify-center mb-6">
                  <Check className="w-10 h-10 text-[#d4af37]" />
                </div>
                <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8] mb-2">
                  Message Sent!
                </h3>
                <p className="text-[#f5f1e8]/60 mb-6">
                  Thank you for reaching out. I'll get back to you as soon as possible. God bless you!
                </p>
                <button
                  onClick={() => setSubmitStatus('idle')}
                  className="text-[#d4af37] hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#f5f1e8] mb-6">
                  Send a Message
                </h3>

                {/* Inquiry Type */}
                <div>
                  <label className="block text-[#f5f1e8]/80 text-sm font-medium mb-2">
                    Inquiry Type
                  </label>
                  <select
                    name="inquiryType"
                    value={formData.inquiryType}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-[#1a2332] border border-[#f5f1e8]/20 rounded-lg text-[#f5f1e8] focus:outline-none focus:border-[#d4af37] transition-colors"
                  >
                    {inquiryTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Name */}
                <div>
                  <label className="block text-[#f5f1e8]/80 text-sm font-medium mb-2">
                    Your Name *
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Your full name"
                      className={`w-full px-4 py-3 pl-11 bg-[#1a2332] border rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none transition-colors ${
                        errors.name
                          ? 'border-red-500'
                          : 'border-[#f5f1e8]/20 focus:border-[#d4af37]'
                      }`}
                    />
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#f5f1e8]/40" />
                  </div>
                  {errors.name && (
                    <p className="mt-1 text-red-400 text-sm flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.name}
                    </p>
                  )}
                </div>

                {/* Email */}
                <div>
                  <label className="block text-[#f5f1e8]/80 text-sm font-medium mb-2">
                    Email Address *
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your@email.com"
                      className={`w-full px-4 py-3 pl-11 bg-[#1a2332] border rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none transition-colors ${
                        errors.email
                          ? 'border-red-500'
                          : 'border-[#f5f1e8]/20 focus:border-[#d4af37]'
                      }`}
                    />
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#f5f1e8]/40" />
                  </div>
                  {errors.email && (
                    <p className="mt-1 text-red-400 text-sm flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.email}
                    </p>
                  )}
                </div>

                {/* Subject */}
                <div>
                  <label className="block text-[#f5f1e8]/80 text-sm font-medium mb-2">
                    Subject *
                  </label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="What's this about?"
                    className={`w-full px-4 py-3 bg-[#1a2332] border rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none transition-colors ${
                      errors.subject
                        ? 'border-red-500'
                        : 'border-[#f5f1e8]/20 focus:border-[#d4af37]'
                    }`}
                  />
                  {errors.subject && (
                    <p className="mt-1 text-red-400 text-sm flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.subject}
                    </p>
                  )}
                </div>

                {/* Message */}
                <div>
                  <label className="block text-[#f5f1e8]/80 text-sm font-medium mb-2">
                    Message *
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Your message..."
                    rows={5}
                    className={`w-full px-4 py-3 bg-[#1a2332] border rounded-lg text-[#f5f1e8] placeholder-[#f5f1e8]/40 focus:outline-none transition-colors resize-none ${
                      errors.message
                        ? 'border-red-500'
                        : 'border-[#f5f1e8]/20 focus:border-[#d4af37]'
                    }`}
                  />
                  {errors.message && (
                    <p className="mt-1 text-red-400 text-sm flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.message}
                    </p>
                  )}
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 bg-[#d4af37] text-[#1a2332] font-semibold rounded-lg hover:bg-[#e5c04a] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
