import React, { useState, useEffect } from 'react';
import { ChevronRight, Star, ShoppingCart, Check, BookOpen } from 'lucide-react';
import { books, heroImage } from '../data/booksData';
import { useCart } from '../contexts/CartContext';

interface HeroProps {
  onNavigate: (section: string) => void;
  onSelectBook: (bookId: number) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate, onSelectBook }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const featuredBook = books.find(b => b.featured) || books[0];
  
  const { addToCart, isInCart } = useCart();
  const inCart = isInCart(featuredBook.id);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(featuredBook);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Books and reading"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2332]/95 via-[#1a2332]/85 to-[#1a2332]/70" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a2332] via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div
            className={`space-y-8 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
            }`}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#d4af37]/20 rounded-full border border-[#d4af37]/30">
              <BookOpen className="w-4 h-4 text-[#d4af37]" />
              <span className="text-[#d4af37] text-sm font-medium">
                Faith-Based Author | Amazon KDP
              </span>
            </div>

            <h1 className="font-['Playfair_Display'] text-4xl sm:text-5xl lg:text-6xl font-bold text-[#f5f1e8] leading-tight">
              Books That
              <span className="block text-[#d4af37]">Transform Lives</span>
            </h1>

            <p className="text-xl text-[#f5f1e8]/70 max-w-lg leading-relaxed">
              Welcome to PapaDavidSnr Bookstore. Discover inspiring books on faith, 
              marriage, and relationships by <span className="text-[#d4af37] font-medium">David Anane Nyarko (Papa David Snr.)</span>
            </p>

            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => onNavigate('books')}
                className="group px-8 py-4 bg-[#d4af37] text-[#1a2332] font-semibold rounded-full hover:bg-[#e5c04a] transition-all hover:shadow-xl hover:shadow-[#d4af37]/20 flex items-center gap-2"
              >
                Browse All Books
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => onNavigate('about')}
                className="px-8 py-4 border-2 border-[#f5f1e8]/30 text-[#f5f1e8] font-semibold rounded-full hover:border-[#d4af37] hover:text-[#d4af37] transition-all"
              >
                About the Author
              </button>
            </div>

            {/* Stats */}
            <div className="flex gap-8 pt-4">
              <div>
                <div className="font-['Playfair_Display'] text-3xl font-bold text-[#d4af37]">4</div>
                <div className="text-sm text-[#f5f1e8]/60">Published Books</div>
              </div>
              <div>
                <div className="font-['Playfair_Display'] text-3xl font-bold text-[#d4af37]">350+</div>
                <div className="text-sm text-[#f5f1e8]/60">Happy Readers</div>
              </div>
              <div>
                <div className="font-['Playfair_Display'] text-3xl font-bold text-[#d4af37]">4.8</div>
                <div className="text-sm text-[#f5f1e8]/60">Avg. Rating</div>
              </div>
            </div>
          </div>

          {/* Featured Book */}
          <div
            className={`relative transition-all duration-1000 delay-300 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            <div className="relative group cursor-pointer" onClick={() => onSelectBook(featuredBook.id)}>
              {/* Glow Effect */}
              <div className="absolute -inset-4 bg-[#d4af37]/20 rounded-2xl blur-2xl group-hover:bg-[#d4af37]/30 transition-all" />
              
              {/* Book Card */}
              <div className="relative bg-[#1a2332]/80 backdrop-blur-sm rounded-2xl p-6 border border-[#f5f1e8]/10 group-hover:border-[#d4af37]/30 transition-all">
                <div className="flex gap-6">
                  {/* Book Cover */}
                  <div className="relative flex-shrink-0">
                    <img
                      src={featuredBook.coverImage}
                      alt={featuredBook.title}
                      className="w-36 sm:w-40 h-52 sm:h-60 object-cover rounded-lg shadow-2xl group-hover:scale-105 transition-transform duration-500"
                    />
                    {featuredBook.isBestSeller && (
                      <div className="absolute -top-3 -right-3 px-3 py-1 bg-[#d4af37] text-[#1a2332] text-xs font-bold rounded-full">
                        BEST SELLER
                      </div>
                    )}
                  </div>

                  {/* Book Info */}
                  <div className="flex flex-col justify-between py-2">
                    <div>
                      <p className="text-[#d4af37] text-sm font-medium mb-2">
                        Featured Book
                      </p>
                      <h3 className="font-['Playfair_Display'] text-xl sm:text-2xl font-bold text-[#f5f1e8] mb-2">
                        {featuredBook.title}
                      </h3>
                      {featuredBook.subtitle && (
                        <p className="text-[#f5f1e8]/60 text-sm mb-3 line-clamp-2">
                          {featuredBook.subtitle}
                        </p>
                      )}
                      <div className="flex items-center gap-2 mb-4">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < Math.floor(featuredBook.rating)
                                  ? 'text-[#d4af37] fill-[#d4af37]'
                                  : 'text-[#f5f1e8]/30'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-[#f5f1e8]/60 text-sm">
                          ({featuredBook.reviewCount} reviews)
                        </span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <p className="text-2xl font-bold text-[#f5f1e8]">
                        ${featuredBook.price.toFixed(2)}
                      </p>
                      <button
                        onClick={handleAddToCart}
                        className={`flex items-center gap-2 px-6 py-2.5 font-semibold rounded-full transition-all ${
                          addedToCart || inCart
                            ? 'bg-green-500 text-white'
                            : 'bg-[#d4af37] text-[#1a2332] hover:bg-[#e5c04a]'
                        }`}
                      >
                        {addedToCart ? (
                          <>
                            <Check className="w-4 h-4" />
                            Added!
                          </>
                        ) : inCart ? (
                          <>
                            <Check className="w-4 h-4" />
                            In Cart
                          </>
                        ) : (
                          <>
                            <ShoppingCart className="w-4 h-4" />
                            Add to Cart
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-[#f5f1e8]/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-3 bg-[#d4af37] rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
