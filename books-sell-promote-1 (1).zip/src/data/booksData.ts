// Actual book cover images from PapaDavidSnr
const bookCovers = {
  whenGodIsSilent: 'https://d64gsuwffb70l.cloudfront.net/690636c13fadace15c0fd107_1767902910656_543811d5.jpeg',
  strengtheningLove: 'https://d64gsuwffb70l.cloudfront.net/690636c13fadace15c0fd107_1767902924339_e75b13dd.jpeg',
  godsPersistence: 'https://d64gsuwffb70l.cloudfront.net/690636c13fadace15c0fd107_1767902943379_26749801.jpeg',
  valuingRelationships: 'https://d64gsuwffb70l.cloudfront.net/690636c13fadace15c0fd107_1767902960883_a3ef131a.jpeg',
};

// Real author images - David Anane Nyarko (Papa David Snr.)
export const authorImages = {
  primary: 'https://d64gsuwffb70l.cloudfront.net/690636c13fadace15c0fd107_1767907090800_21dad39e.png', // White outfit in library
  secondary: 'https://d64gsuwffb70l.cloudfront.net/690636c13fadace15c0fd107_1767907104369_32c0e4ef.png', // Green suit
};

// Keep backward compatibility
export const authorImage = authorImages.primary;

// Hero background image
export const heroImage = 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=1920&h=1080&fit=crop';

export interface Book {
  id: number;
  title: string;
  subtitle?: string;
  genre: string;
  series?: string;
  seriesNumber?: number;
  publishDate: string;
  price: number;
  rating: number;
  reviewCount: number;
  coverImage: string;
  synopsis: string;
  excerpt: string;
  awards?: string[];
  amazonLink: string;
  barnesNobleLink: string;
  indieLink: string;
  featured?: boolean;
  isBestSeller?: boolean;
  inStock?: boolean;
}

export const books: Book[] = [
  {
    id: 1,
    title: "God's Persistence",
    subtitle: "A Journey of Faith Through Trials and Triumphs",
    genre: "Christian Living",
    series: "Faith Journey",
    seriesNumber: 1,
    publishDate: "2024-06-15",
    price: 9.99,
    rating: 4.9,
    reviewCount: 156,
    coverImage: bookCovers.godsPersistence,
    synopsis: "In 'God's Persistence,' David Anane Nyarko takes readers on an inspiring journey through the unwavering nature of God's love and faithfulness. This powerful book explores how God continues to pursue us even when we feel lost, distant, or unworthy. Through personal testimonies, biblical insights, and practical wisdom, discover how God's persistent love can transform your life and strengthen your faith journey.",
    excerpt: "There are moments in life when we feel God has forgotten us. The silence seems deafening, the darkness overwhelming. But it is precisely in these moments that God's persistence shines brightest. He never stops pursuing us, never stops loving us, never stops working on our behalf...",
    awards: ["Best Seller"],
    amazonLink: "https://www.amazon.com/dp/B0FQGJVSXS",
    barnesNobleLink: "#",
    indieLink: "#",
    featured: true,
    isBestSeller: true,
    inStock: true
  },
  {
    id: 2,
    title: "Strengthening Love",
    subtitle: "Navigating the Trials of Marriage",
    genre: "Marriage & Relationships",
    series: "Relationship Wisdom",
    seriesNumber: 1,
    publishDate: "2024-08-20",
    price: 13.85,
    rating: 4.8,
    reviewCount: 89,
    coverImage: bookCovers.strengtheningLove,
    synopsis: "Marriage is a beautiful journey, but it's not without its challenges. In 'Strengthening Love,' David Anane Nyarko provides couples with practical, faith-based guidance for navigating the trials that every marriage faces. From communication breakdowns to financial stress, from raising children to maintaining intimacy, this book offers wisdom rooted in biblical principles and real-world experience.",
    excerpt: "Love is not just a feeling—it's a choice we make every single day. When the honeymoon phase fades and reality sets in, that's when true love begins. It's in the mundane moments, the difficult conversations, and the choice to stay when leaving seems easier...",
    amazonLink: "https://www.amazon.com/dp/B0FGHT1YK4",
    barnesNobleLink: "#",
    indieLink: "#",
    inStock: true
  },
  {
    id: 3,
    title: "Valuing Relationships",
    subtitle: "How to Build Deeper Bonds Without Stress",
    genre: "Self-Help",
    series: "Relationship Wisdom",
    seriesNumber: 2,
    publishDate: "2024-10-10",
    price: 14.90,
    rating: 4.7,
    reviewCount: 67,
    coverImage: bookCovers.valuingRelationships,
    synopsis: "In our fast-paced world, meaningful relationships often take a backseat to busy schedules and digital distractions. 'Valuing Relationships' is a comprehensive guide to building and maintaining deep, fulfilling connections with the people who matter most. David Anane Nyarko shares practical strategies for nurturing friendships, family bonds, and professional relationships without the stress and anxiety that often accompanies social interactions.",
    excerpt: "The quality of your life is directly proportional to the quality of your relationships. Yet so many of us struggle to form and maintain meaningful connections. We're surrounded by people but feel utterly alone. This book will change that...",
    amazonLink: "https://www.amazon.com/dp/B0FF6TSGDV",
    barnesNobleLink: "#",
    indieLink: "#",
    inStock: true
  },
  {
    id: 4,
    title: "When God is Silent",
    subtitle: "Trusting in the Midst of God's Quietness",
    genre: "Spiritual Growth",
    series: "Faith Journey",
    seriesNumber: 2,
    publishDate: "2025-01-05",
    price: 14.85,
    rating: 4.9,
    reviewCount: 42,
    coverImage: bookCovers.whenGodIsSilent,
    synopsis: "What do you do when your prayers seem to hit the ceiling? When God feels distant and silent? In this profound exploration of divine silence, David Anane Nyarko addresses one of the most challenging aspects of faith. 'When God is Silent' offers comfort, understanding, and practical guidance for those walking through seasons of spiritual dryness, helping readers discover that even in silence, God is at work.",
    excerpt: "The desert was vast and empty. I had been praying for weeks, months even, and heaven seemed closed. But it was in that silence that I learned the most profound lesson of my faith journey: God's silence is not His absence. Sometimes He is silent because He is working on something too magnificent for words...",
    amazonLink: "https://www.amazon.com/dp/B0F3L7FDJZ",
    barnesNobleLink: "#",
    indieLink: "#",
    inStock: true
  }
];

export interface Review {
  id: number;
  bookId: number;
  bookTitle: string;
  reviewer: string;
  rating: number;
  text: string;
  source?: string;
  date: string;
}

export const reviews: Review[] = [
  {
    id: 1,
    bookId: 1,
    bookTitle: "God's Persistence",
    reviewer: "Grace M.",
    rating: 5,
    text: "This book changed my perspective on God's love. Papa David Snr. has a gift for making complex spiritual truths accessible and practical. A must-read for anyone going through difficult seasons.",
    date: "2024-07-15"
  },
  {
    id: 2,
    bookId: 1,
    bookTitle: "God's Persistence",
    reviewer: "Emmanuel K.",
    rating: 5,
    text: "I couldn't put this book down. Every chapter spoke directly to my situation. The author's personal stories made the message even more powerful.",
    date: "2024-08-02"
  },
  {
    id: 3,
    bookId: 2,
    bookTitle: "Strengthening Love",
    reviewer: "Sarah & John D.",
    rating: 5,
    text: "My husband and I read this together, and it transformed our marriage. The practical advice combined with biblical wisdom is exactly what couples need today.",
    date: "2024-09-10"
  },
  {
    id: 4,
    bookId: 2,
    bookTitle: "Strengthening Love",
    reviewer: "Pastor Michael A.",
    rating: 5,
    text: "I recommend this book to every couple in my congregation. David Anane Nyarko addresses real marriage issues with grace, wisdom, and practical solutions.",
    source: "Church Leader Review",
    date: "2024-09-25"
  },
  {
    id: 5,
    bookId: 3,
    bookTitle: "Valuing Relationships",
    reviewer: "Rebecca T.",
    rating: 5,
    text: "As someone who struggles with social anxiety, this book was a game-changer. The stress-free approach to building relationships is refreshing and actually works!",
    date: "2024-11-05"
  },
  {
    id: 6,
    bookId: 3,
    bookTitle: "Valuing Relationships",
    reviewer: "Daniel O.",
    rating: 4,
    text: "Practical, insightful, and deeply rooted in faith. This book helped me repair broken relationships and build new, meaningful ones.",
    date: "2024-11-20"
  },
  {
    id: 7,
    bookId: 4,
    bookTitle: "When God is Silent",
    reviewer: "Mary L.",
    rating: 5,
    text: "I was going through the darkest season of my life when I found this book. It was like God speaking directly to me through Papa David Snr.'s words. Absolutely life-changing.",
    date: "2025-01-10"
  },
  {
    id: 8,
    bookId: 4,
    bookTitle: "When God is Silent",
    reviewer: "James N.",
    rating: 5,
    text: "The most comforting book I've ever read about spiritual dryness. The author doesn't offer empty platitudes but real, biblical hope.",
    date: "2025-01-15"
  }
];

export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  category: string;
  readTime: number;
  image?: string;
}

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Finding Strength in God's Silence",
    excerpt: "When prayers seem unanswered, discover how to find peace and purpose in the waiting.",
    content: "There are seasons in every believer's life when God seems distant. The prayers feel hollow, the heavens seem brass...",
    date: "2025-01-08",
    category: "Faith",
    readTime: 6
  },
  {
    id: 2,
    title: "5 Keys to a Stronger Marriage",
    excerpt: "Practical wisdom for couples who want to build a lasting, loving relationship.",
    content: "Marriage is a beautiful gift, but it requires intentional effort to thrive...",
    date: "2024-12-20",
    category: "Marriage",
    readTime: 8
  },
  {
    id: 3,
    title: "Why Relationships Matter More Than Success",
    excerpt: "In our achievement-driven world, we often forget what truly matters.",
    content: "I've met many successful people who are deeply unhappy. The common thread? Broken relationships...",
    date: "2024-12-05",
    category: "Relationships",
    readTime: 5
  },
  {
    id: 4,
    title: "The Power of Persistent Faith",
    excerpt: "How to keep believing when circumstances say otherwise.",
    content: "Faith isn't the absence of doubt—it's the decision to trust God despite the doubt...",
    date: "2024-11-15",
    category: "Faith",
    readTime: 7
  },
  {
    id: 5,
    title: "Building Meaningful Connections in a Digital Age",
    excerpt: "How to nurture real relationships in an increasingly virtual world.",
    content: "We're more connected than ever, yet loneliness is at an all-time high...",
    date: "2024-10-28",
    category: "Relationships",
    readTime: 6
  },
  {
    id: 6,
    title: "When Your Spouse Doesn't Understand",
    excerpt: "Navigating communication challenges in marriage with grace and patience.",
    content: "One of the most common complaints I hear from couples is 'My spouse just doesn't understand me'...",
    date: "2024-10-10",
    category: "Marriage",
    readTime: 9
  }
];

export interface Event {
  id: number;
  title: string;
  type: 'signing' | 'reading' | 'speaking' | 'virtual' | 'festival';
  date: string;
  time: string;
  location: string;
  address?: string;
  description: string;
  registrationLink?: string;
  isFree: boolean;
  spotsLeft?: number;
}

export const events: Event[] = [
  {
    id: 1,
    title: "Virtual Book Launch: When God is Silent",
    type: "virtual",
    date: "2025-02-15",
    time: "7:00 PM GMT",
    location: "Zoom Webinar",
    description: "Join Papa David Snr. for the official launch of 'When God is Silent.' Includes a reading, Q&A session, and special prayer time.",
    registrationLink: "#",
    isFree: true,
    spotsLeft: 200
  },
  {
    id: 2,
    title: "Marriage Workshop: Strengthening Your Bond",
    type: "speaking",
    date: "2025-03-08",
    time: "10:00 AM GMT",
    location: "Grace Community Church",
    address: "Accra, Ghana",
    description: "A half-day workshop for couples based on the principles from 'Strengthening Love.' Includes practical exercises and group discussions.",
    registrationLink: "#",
    isFree: false,
    spotsLeft: 50
  },
  {
    id: 3,
    title: "Author Meet & Greet",
    type: "signing",
    date: "2025-03-22",
    time: "2:00 PM GMT",
    location: "Legon Bookshop",
    address: "University of Ghana, Legon",
    description: "Meet Papa David Snr. in person! Get your books signed and enjoy a time of fellowship and encouragement.",
    registrationLink: "#",
    isFree: true,
    spotsLeft: 75
  },
  {
    id: 4,
    title: "Faith & Relationships Conference",
    type: "festival",
    date: "2025-04-12",
    time: "9:00 AM GMT",
    location: "National Theatre",
    address: "Accra, Ghana",
    description: "A full-day conference exploring the intersection of faith and relationships. Papa David Snr. will be a keynote speaker.",
    registrationLink: "#",
    isFree: false,
    spotsLeft: 300
  }
];

export const genres = ["All", "Christian Living", "Marriage & Relationships", "Self-Help", "Spiritual Growth"];
export const series = ["All Series", "Faith Journey", "Relationship Wisdom"];

// Social Media Links
export const socialLinks = {
  instagram: "https://www.instagram.com/papadavidsnr",
  facebook: "https://www.facebook.com/papadavidsnr",
  twitter: "https://twitter.com/Papa_davd_Snr",
  tiktok: "https://www.tiktok.com/@papadavidsnr",
  linkedin: "https://www.linkedin.com/in/david-anane-nyarko-71b6b61b8/",
  email: "papadavidsnr@gmail.com",
  paypal: "david.anane@yahoo.com",
};
